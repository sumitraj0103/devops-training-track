import {useCallback, useEffect, useState} from 'react'
import './App.css'
import {ServiceModel} from './api'
import api from './api_instance.ts'
import {
    Box,
    ThemeProvider
} from '@mui/material'
import NewService from './NewService.tsx'
import Services from './Services.tsx'


import "swagger-ui-react/swagger-ui.css"
import {theme} from './theme.tsx'

import {defineCustomElements} from '@sfc/components/dist/loader';
import React from 'react'

defineCustomElements(window, {
    resourcesUrl: 'sfc/',
});

function App() {
    const [, setResponse] = useState(undefined);
    const [services, setServices] = useState<Array<ServiceModel>>([])


    const listServices = useCallback(() => {
        api.getServicesServicesGet({uid: 1}).then(setServices)
    }, [])

    useEffect(() => {
        listServices()
    }, [])

    const [darkMode, setDarkMode] = useState(false);

    const handleThemeChange = () => {
        setDarkMode(!darkMode);
        theme.palette.mode = darkMode ? 'light' : 'dark';
    };

    return (
        <ThemeProvider theme={theme}>
            <Box className="sfc-body-color-background" sx={{
                color: 'black',
                display: 'flex',
                flexDirection: 'column',
                textAlign: 'left',
                justifyContent: 'center',
                alignItems: 'center',
                margin: '0 auto',
                width: '100vw',
                borderColor: 'var(--sfc-color-border-default)'
            }}>
                <nav className="sfc-body-color-background" style={{
                    borderWidth: 1,
                    borderStyle: 'solid',
                    borderColor: 'var(--sfc-color-border-default)',
                    width: '100%',
                    display: 'flex',
                    flexDirection: 'row',
                    paddingTop: 15,
                    paddingBottom: 5
                }}>
                    <div style={{width: '60vw', textAlign: 'left', margin: '0 auto'}}>
                        <h1 className='sfc-heading-1'>
                            IDEAS Control Panel
                        </h1>
                    </div>
                </nav>

                <Box
                    sx={{width: '60vw', textAlign: 'left', margin: '0 auto'}}>
                    <Box sx={{width: '100%'}}>
                        <Services listServices={listServices} services={services}/>
                    </Box>
                    <Box sx={{width: '100%'}}>
                        <NewService afterCreate={(res) => {
                            listServices();
                            setResponse(res)
                        }}/>
                    </Box>
                </Box>
            </Box>
        </ThemeProvider>
    )
}

export default App
