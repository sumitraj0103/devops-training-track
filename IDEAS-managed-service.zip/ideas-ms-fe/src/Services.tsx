import React, {useState, useEffect, useCallback} from 'react';
import {Box, Button, Typography, Accordion, AccordionSummary, AccordionDetails, List, ListItem} from '@mui/material';
import SwaggerUI from 'swagger-ui-react';
import 'swagger-ui-react/swagger-ui.css';
import api from './api_instance';
import {Circle} from '@mui/icons-material';
import {Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper} from '@mui/material';
import {SfcButton} from "@sfc/components/dist/sfc-react";

const Services = ({listServices, services}) => {
    const [, setResponse] = useState(undefined);

    const [costs, setCosts] = useState({})

    useEffect(() => {
        listServices();
    }, [listServices]);

    const fetchCost = useCallback((appName: string)=>{
        api.getCostsCostsGet({
            uid: 1,
            appName: appName
        }).then((res)=>{
            setCosts((c)=>{return {...c, [appName]: res}})
        })
    }, [])

    return (
        <Box sx={{marginTop: 3}}>
            <Typography class="sfc-heading-2" variant="h5" sx={{marginBottom: 3}}>Your IDEAS Services</Typography>
            {services.length ? services.map((x) => (
                <Accordion key={x.partitionKey} style={{
                    backgroundColor: 'var(--sfc-body-color-background-subtle)',
                    boxShadow: 'none'
                }}>
                    <AccordionSummary
                        sx={{display: 'flex', alignItems: 'center'}}>
                        <Circle sx={{
                            marginTop: '4px',
                            fontSize: 12,
                            color: x.status === 'Running' ? 'green' : 'red',
                            marginRight: 1
                        }}/>
                        <h6 className='sfc-heading-6' style={{fontSize: 18}}>{x.name} - {x.status}</h6>
                    </AccordionSummary>
                    <AccordionDetails>
                        <Accordion>
                            <AccordionSummary>
                                <h6 className='sfc-heading-6' style={{fontSize: 18}}>Manage</h6>
                            </AccordionSummary>
                            <AccordionDetails>
                                <Typography variant="h6">Provisioning state: {x.provisioningState}</Typography>
                                {costs[x.name] == undefined? <Button onClick={()=>fetchCost(x.name)}>Fetch costs</Button>:<Typography>${costs[x.name].toFixed(2)}</Typography>}
                                <Typography variant="h6" sx={{marginTop: 2}}>Images deployed in this
                                    service</Typography>
                                <p style={{marginTop: 0}}>Provisioning state: {x.provisioningState}</p>
                                <h4 className='sfc-heading-4' style={{}} sx={{marginTop: 2}}>Images deployed in this
                                    service</h4>
                                {x.images.length ? (
                                    <TableContainer component={Paper} sx={{
                                        marginTop: 1,
                                        backgroundColor: 'var(--sfc-body-color-background-subtle)',
                                        boxShadow: 'none'
                                    }}>
                                        <Table>
                                            <TableBody>
                                                {x.images.map((image) => (
                                                    <TableRow key={image}>
                                                        <TableCell
                                                            sx={{padding: '4px', height: '24px'}}>{image}</TableCell>
                                                    </TableRow>
                                                ))}
                                            </TableBody>
                                        </Table>
                                    </TableContainer>
                                ) : <p className="sfc-paragraph">No images yet!</p>}
                                <h4 className='sfc-heading-4' style={{marginTop: 15}}> Deployments for this service </h4>
                                {x.deployments.length ? (
                                    <TableContainer component={Paper} sx={{
                                        marginTop: 1,
                                        backgroundColor: 'var(--sfc-body-color-background-subtle)',
                                        boxShadow: 'none'
                                    }}>
                                        <Table>
                                            <TableBody>
                                                {x.deployments.sort().map((id) => (
                                                    <TableRow key={id}>
                                                        <TableCell sx={{padding: '4px', height: '24px'}}>
                                                            <a target="_blank" rel="noopener noreferrer"
                                                               href={`https://dev.azure.com/raboweb/Tribe%20Data%20and%20Analytics/_build/results?buildId=${id}&view=results`}>{id}</a>
                                                        </TableCell>
                                                    </TableRow>
                                                ))}
                                            </TableBody>
                                        </Table>
                                    </TableContainer>
                                ) : <p className="sfc-paragraph">No deployments yet!</p>}

                                <div style={{display: 'flex', gap: 10, marginTop: 20}}>
                                    <SfcButton style={{width: '30%'}} variant='secondary' onClick={() => api.runPipelineRunPipelineGet({
                                        rowKey: x.rowKey,
                                        partKey: x.partitionKey
                                    }).then(setResponse)}>(Re)Deploy</SfcButton>
                                    <SfcButton style={{width: '30%'}} variant='secondary'  onClick={() => api.deleteServiceServiceDelete({
                                        rowKey: x.rowKey,
                                        partKey: x.partitionKey
                                    }).then((res) => {
                                        setResponse(res);
                                        listServices();
                                    })}>Delete</SfcButton>
                                </div>

                            </AccordionDetails>
                        </Accordion>
                        <Accordion>
                            <AccordionSummary>
                                <h6 className='sfc-heading-6' style={{fontSize: 18}}>Test</h6>
                            </AccordionSummary>
                            <AccordionDetails>
                                <Box sx={{textAlign: 'left'}}>
                                    <SwaggerUI
                                        url={`https://${x.name}-1.bravesand-0b29fb7c.westeurope.azurecontainerapps.io/openapi.json`}
                                        requestInterceptor={(req) => {

                                            return req;
                                        }}/>
                                </Box>
                            </AccordionDetails>
                        </Accordion>
                    </AccordionDetails>
                </Accordion>
            )) : <p className="sfc-paragraph">No services yet! Create one below.</p>}
        </Box>
    );
};

export default Services;