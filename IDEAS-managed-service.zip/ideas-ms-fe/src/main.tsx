import {StrictMode} from 'react'
import {createRoot} from 'react-dom/client'
import './index.css'
import App from './App.tsx'

import {defineCustomElements} from '@sfc/components/dist/loader';

defineCustomElements(window, {
    resourcesUrl: 'sfc/',
});

createRoot(document.getElementById('root')!).render(
    <StrictMode>
        <App/>
    </StrictMode>,
)
