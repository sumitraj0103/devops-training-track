import { BodyPutServiceServicePutFromJSON, Configuration, DefaultApi, ServiceModel } from './api'

const api = new DefaultApi(
    new Configuration({
        basePath: import.meta.env.VITE_APP_HOST ?? "http://localhost:8000"
    }))

export default api
