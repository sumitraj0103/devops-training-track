import {Box, Divider} from "@mui/material";
import {SfcSelect, SfcOption, SfcInput, SfcButton} from "@sfc/components/dist/sfc-react";
import {useCallback, useRef, useState, React, useEffect} from "react";
import api from "./api_instance";
import {Prism as SyntaxHighlighter} from 'react-syntax-highlighter';
import {oneLight} from 'react-syntax-highlighter/dist/esm/styles/prism';

import {defineCustomElements} from '@sfc/components/dist/loader';

defineCustomElements(window, {
    resourcesUrl: 'sfc/',
});


interface IDEASConfig {
    documentType?: string;
    fields?: Array<{ name: string, description: string, key: number }>;
    requirements?: Array<{ requirement: string, detail: string, key: number }>;
    classes?: Array<{ name: string, description: string, key: number }>;
}

interface ServiceType {
    arrayName: string;
    properties: string[];
}

const serviceTypes: { [key: string]: ServiceType } = {
    "extraction": {arrayName: "fields", properties: ["name", "description", "type"]},
    "validation": {arrayName: "requirements", properties: ["name", "description"]},
    "classification": {arrayName: "classes", properties: ["name", "description"]},
    "interpretation": {arrayName: "fields", properties: ["name", "description", "type"]}
};

function NewService({afterCreate}: { afterCreate: (a: any) => void }) {
    const [appName, setAppName] = useState("");
    const [serviceType, setServiceType] = useState("extraction");
    const keyRef = useRef(2);
    const [appConfig, setAppConfig] = useState<IDEASConfig>({
        documentType: "",
        [serviceTypes[serviceType].arrayName]: [{key: 1, ...Object.fromEntries(serviceTypes[serviceType].properties.map(prop => [prop, ""]))}]
    });

    const arrayName: string = serviceTypes[serviceType].arrayName;
    const properties = serviceTypes[serviceType].properties;

    const createService = useCallback(() => {

        const appConfigTransfer = JSON.parse(JSON.stringify(appConfig));

        appConfigTransfer['type'] = serviceType;

        if (serviceType == 'interpretation') {
            appConfigTransfer['type'] = 'extraction';
        }

        const serviceSpecification = {
            type: appConfigTransfer['type'],
            config: appConfigTransfer,
            name: appName
        }

        api.putServiceServicePut({
            uid: 1,
            serviceSpecification: serviceSpecification
        })
            .then(afterCreate)
            .catch((e) => console.log(e));
    }, [appName, appConfig]);

    const handleServiceTypeChange = (e: React.ChangeEvent<{ value: unknown }>) => {
        const newServiceType = e.target.value as string;
        setServiceType(newServiceType);
        const newAppConfig = {
            [serviceTypes[newServiceType].arrayName]: [{key: 1, ...Object.fromEntries(serviceTypes[newServiceType].properties.map(prop => [prop, ""]))}]
        };
        if (newServiceType !== "classification") {
            newAppConfig.documentType = "";
        }
        setAppConfig(newAppConfig);
        keyRef.current = 2;
    };

    return (
        <Box sx={{display: 'flex', flexDirection: 'column', gap: 1, marginTop: 5, color: 'white'}}>

            <h2 className="sfc-heading-2">Create New IDEAS Service</h2>

            <Box sx={{padding: 1, display: 'flex', flexDirection: 'column', gap: 1}}>

                <SfcSelect
                    label="Service Type"
                    placeholder="Service Type"
                    onSfcChange={handleServiceTypeChange}
                    required
                >
                    {Object.keys(serviceTypes).map((type) => (
                        <SfcOption value={type}>{type}</SfcOption>
                    ))}

                </SfcSelect>

                <SfcInput
                    label="Service Name"
                    placeholder="Service Name"
                    onSfcChange={(e) => setAppName(e.target.value)}
                    required
                ></SfcInput>

                {serviceType !== "classification" && (
                    <SfcInput
                        label="Document type"
                        placeholder="Document type"
                        onSfcInput={(e) => {
                            setAppConfig((c) => {
                                return {...c, documentType: e.target.value};
                            });
                        }}
                        required
                    ></SfcInput>
                )}


                <h5 className='sfc-heading-5'
                    style={{color: 'black', fontSize: 17}}
                >{arrayName.charAt(0).toUpperCase() + arrayName.slice(1)}</h5>

                <div className='sfc-body-color-background-subtle'
                     style={{
                         display: 'flex',
                         flexDirection: 'column',
                         gap: 2,
                         borderRadius: 10,
                         padding: 10,
                     }}>
                    {
                        // @ts-expect-error dynamic key
                        appConfig[arrayName]?.map((item, pos) => (
                            <Box key={item.key} sx={{display: 'flex', gap: 1, width: '100%', height: '55px'}}>
                                {properties.map((prop) => (
                                    <SfcInput
                                        style={{flex: 1}}
                                        key={prop}
                                        type="text"
                                        placeholder={prop.charAt(0).toUpperCase() + prop.slice(1)}
                                        onSfcInput={(e) => setAppConfig((c) => {
                                            // @ts-expect-error dynamic key
                                            const n = c[arrayName]!;
                                            n[pos] = {...n[pos], [prop]: e.target.value};
                                            return {...c, [arrayName]: n};
                                        })}
                                    />
                                ))}
                                <SfcButton style={{flexSHrink: 0}} variant='secondary' onClick={() => {
                                    const c = appConfig;
                                    // @ts-expect-error dynamic key
                                    const n = c[arrayName]!;
                                    for (let i = pos; i < n.length - 1; i++) {
                                        n[i] = n[i + 1];
                                    }
                                    n.pop();
                                    setAppConfig({...c, [arrayName]: n});
                                }}>Remove</SfcButton>
                            </Box>
                        ))}
                    <SfcButton style={{marginTop: 4}} variant='secondary' className='add-field-button'
                               onSfcClick={() => {
                                   let c = appConfig;
                                   // @ts-expect-error dynamic key
                                   const n = c[arrayName]!;
                                   const newItem = properties.reduce((acc, prop) => ({
                                       ...acc,
                                       [prop]: ""
                                   }), {key: keyRef.current});
                                   keyRef.current++;
                                   n.push(newItem);
                                   c = {...c, [arrayName]: n};
                                   setAppConfig(c);
                               }}>Add Element
                    </SfcButton>
                </div>

                <SfcButton variant="primary" onClick={createService}>Create Service</SfcButton>

                <Divider sx={{my: 2, borderColor: 'rgba(255, 255, 255, 0.3)'}}/>

                <h5 className='sfc-heading-5'
                    style={{color: 'black', fontSize: 17}}>Config JSON View</h5>
                <Box>
                    <SyntaxHighlighter language="json" style={oneLight}>
                        {JSON.stringify(appConfig, null, 2)}
                    </SyntaxHighlighter>
                </Box>
            </Box>
        </Box>
    );
}

export default NewService;