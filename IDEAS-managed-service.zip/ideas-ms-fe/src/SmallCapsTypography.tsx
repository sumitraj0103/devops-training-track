import { Typography } from "@mui/material";

interface SmallCapsTypographyProps {
    text: string;
}

const SmallCapsTypography: React.FC<SmallCapsTypographyProps> = ({ text }) => {
    return (
        <Typography variant="subtitle2" sx={{
            textTransform: 'uppercase',
            fontSize: '0.75rem',
            fontWeight: 'bold',
            color: 'gray',
            marginTop: 1,
        }}>
            {text}
        </Typography>
    );
};

export default SmallCapsTypography;