curl http://127.0.0.1:8000/openapi.json > temp.json

rm -r src/api

docker run --rm \
  -v ${PWD}:/local openapitools/openapi-generator-cli generate \
  -i /local/temp.json \
  -g typescript-fetch \
  -o /local/src/api

rm temp.json