[![Build Status](https://dev.azure.com/raboweb/Tribe%20Data%20and%20Analytics/_apis/build/status%2FTribe%20Data%20%26%20Analytics%2FTribe%20DAPT%2FArea%20Analytics%20Acceleration%2FSquad%20GeMS%20IDEAS%2FIDEAS-managed-service%20sanity%20test?branchName=main&label=Sanity%20check)](https://dev.azure.com/raboweb/Tribe%20Data%20and%20Analytics/_build/latest?definitionId=75933&branchName=main)
[![Build Status](https://dev.azure.com/raboweb/Tribe%20Data%20and%20Analytics/_apis/build/status%2FTribe%20Data%20%26%20Analytics%2FTribe%20DAPT%2FArea%20Analytics%20Acceleration%2FSquad%20GeMS%20IDEAS%2FIDEAS%20Deploy?branchName=main&label=Deploy)](https://dev.azure.com/raboweb/Tribe%20Data%20and%20Analytics/_build/latest?definitionId=73353&branchName=main)
# Introduction 
Welcome to the Read Managed Service project. This project aims to provide a comprehensive solution for managing and deploying customized services for extracting structured data from unstructured documents. Our goal is to simplify the process of service management, making it easier for developers and administrators to handle their tasks with ease.

# Getting Started
- Create a `.env` file in the root directory of the project and add the necessary environment variables. Here is an example of what the `.env` file might look like:

```
AZURE_STORAGE_CONNECTION_STRING=<Your azure storage connection string>
AZURE_TENANT_ID=<The tenant id for the app>
AZURE_CLIENT_ID=<The app (read-managed-service) app client id>
AZURE_CLIENT_SECRET=<read-managed-service client secret>
AZURE_OPENAI_KEY=
AZURE_OPENAI_ENDPOINT=
NEXUSCLOUD_USERNAME=
NEXUSCLOUD_PASSWORD=
NEXUSCLOUD_TOKEN=
POSTGRES_PASSWORD=
DATABASE_URL=
```

Make sure to replace the placeholder values with your actual configuration settings

- Make and fill up the following two files [pipeline_pat.secret](ideas-ms-be/pipeline_pat.secret) and [storage_conn_string.secret](ideas-ms-be/storage_conn_string.secret) in the [read-ms-be](read-ms-be) directory with your personal access token and the storage connection string

# Build and Test
### Running containerized
- `docker-compose up --build -d`

### Running app locally
- `cd app`
- `make restart-db clear-migrations`
- `make run_app_extract`

### Testing
Please make sure the containerized stack is running
- `cd tests/sanity`
- `python3 -m unittest discover -v`

For more context, please refer to the [Makefile](app/Makefile), [sanity_test.yml](pipelines/sanity_test.yml) and the [docker-compose.yml](docker-compose.yml) files

In order to run sanity tests, you need to issue the following commands first if you are on a Mac.
```
brew install coreutils
alias timeout=gtimeout
```

Run `docker-compose up -d`

# Contribute
Please format your code with `make pretty` inside the [app](app) folder before committing.

- [Visual Studio Code](https://github.com/Microsoft/vscode)

# Gotchas
- On macs, please ensure your docker installation can access the host's network, since the host machine's VPN is leveraged for the connection. This can be solved by using the QEMU emulation framework.