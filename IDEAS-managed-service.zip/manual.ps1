$appname = 'ideas-ms-fe'
$app = Get-AzContainerApp -ResourceGroupName rg_robin -Name $appname
$rev = Get-AzContainerAppRevision -ContainerAppInputObject $app -Name $app.LatestRevisionName 
while($rev.TrafficWeight -ne 100){Start-Sleep -Seconds 1; $rev = Get-AzContainerAppRevision -ContainerAppInputObject $app -Name $app.LatestRevisionName}
while($rev.RunningState -ne 'Running'){Start-Sleep -Seconds 1; $rev = Get-AzContainerAppRevision -ContainerAppInputObject $app -Name $app.LatestRevisionName}
$fqdn=$app.LatestRevisionFqdn

$name = $fqdn.split('.')[0,1] -Join '.' 
$Records = @()
$Records += New-AzPrivateDnsRecordConfig -IPv4Address 10.0.5.1
try {
    New-AzPrivateDnsRecordSet -ResourceGroupName rg_robin -ZoneName westeurope.azurecontainerapps.io -Name $name -RecordType A -TTL 3600 -PrivateDnsRecords $Records -ErrorAction stop
} catch{}
$apimContext = New-AzApiManagementContext -ResourceGroupName "rg_robin" -ServiceName "apimrobin2" 
try {
    $operation=New-AzApiManagementOperation -Context $apimContext -ApiId specs -Name $appname-spec -Method get -UrlTemplate $appname-spec -ErrorAction stop
} catch{
    $operations=Get-AzApiManagementOperation -Context $apimContext -ApiId specs
    $operation=$operations | where {$_.Name -eq "$appname-spec"}  
}
Set-AzApiManagementPolicy -Context $apimContext -ApiId specs -OperationId $operation.Id.split("/")[-1] -Policy "<policies><inbound><base /><set-backend-service base-url='https://$fqdn' /><rewrite-uri template='/openapi.json' /></inbound></policies>" 



$remainingTries=10
$succes=$false
while((-not $succes) -and ($remainingTries -ge 0)){
    try{
                Import-AzApiManagementApi -Context $apimContext -ApiId $appname  -SpecificationUrl https://apimrobin2.azure-api.net/specs/$appname-spec -ServiceUrl https://$fqdn -SpecificationFormat OpenApiJson -Path $appname -ErrorAction stop
        $succes=$true
    } catch {
        $remainingTries = $remainingTries - 1
        Write-Output "Operation Failed; going to retry $remainingTries times"
        Start-Sleep -Seconds 5
    }
}