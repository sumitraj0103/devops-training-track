import json
import traceback
import os
from typing import List
from uuid import uuid4
from dotenv import load_dotenv
from fastapi import Body, FastAPI, HTTPException
from azure.identity import ManagedIdentityCredential, ClientSecretCredential
from azure.keyvault.secrets import SecretClient
import requests
import uvicorn
from pydantic import constr
from datetime import *

from azure.mgmt.costmanagement import CostManagementClient
from azure.mgmt.costmanagement.models import QueryDefinition, QueryDataset, QueryTimePeriod, QueryAggregation, QueryGrouping , QueryFilter, QueryComparisonExpression

from settings import ORGANIZATION, project, pipeline_id, subscription, registry_url
from requests.auth import HTTPBasicAuth
from fastapi.middleware.cors import CORSMiddleware
from DTO import ServiceModel, ServiceSpecification
from azure.mgmt.resource import ResourceManagementClient
from azure.core.exceptions import ResourceNotFoundError, HttpResponseError
import re

load_dotenv()

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

AZURE_TENANT_ID = "6e93a626-8aca-4dc1-9191-ce291b4b75a1"
KEY_VAULT_ENDPOINT = os.getenv("KEY_VAULT_ENDPOINT", "https://testkvrobin.vault.azure.net/")

MANAGED_IDENTITY_CLIENT_ID = os.getenv("MANAGED_IDENTITY_CLIENT_ID")
if MANAGED_IDENTITY_CLIENT_ID is not None:
    print("Using managed identity")
    credential = ManagedIdentityCredential(client_id=MANAGED_IDENTITY_CLIENT_ID)
    client = SecretClient(vault_url=KEY_VAULT_ENDPOINT, credential=credential)
    PIPELINE_PAT = client.get_secret("PIPELINE-PAT").value
    SA_CONN_STRING = client.get_secret("SA-CONN-STRING").value
else:
    authority = 'https://login.microsoftonline.com'
    CLIENT_ID = os.getenv("CLIENT_ID")
    CLIENT_SECRET = os.getenv("CLIENT_SECRET")
    if CLIENT_ID is None or CLIENT_ID == "" or CLIENT_SECRET is None or CLIENT_SECRET == "":
        raise Exception("No managed identy found, and at least one of CLIENT_ID and CLIENT_SECRET is missing!")
    credential = ClientSecretCredential(AZURE_TENANT_ID, CLIENT_ID, CLIENT_SECRET, authority=authority)
    client = SecretClient(vault_url=KEY_VAULT_ENDPOINT, credential=credential)
    PIPELINE_PAT = client.get_secret("PIPELINE-PAT").value
    SA_CONN_STRING = client.get_secret("SA-CONN-STRING").value

from azure.data.tables import TableServiceClient, UpdateMode
from azure.containerregistry import ContainerRegistryClient

table_service = TableServiceClient.from_connection_string(conn_str=SA_CONN_STRING)
resource_client = ResourceManagementClient(credential, subscription)

# Initialize ContainerRegistryManagementClient
client = ContainerRegistryClient(endpoint=registry_url, credential=credential)

table_client = table_service.get_table_client(table_name="read")
cost_client = CostManagementClient(credential)


def resource_group_name(appName: str, uid: int):
    return f"rg_{appName}_{uid}"

def appName(appName: str, uid: int):
    return f"{appName}-{uid}"

@app.get("/services", response_model=List[ServiceModel])
def get_services(uid: int):
    entities = list(table_client.query_entities(f"uid eq {uid}"))
    for ent in entities:
        try:
            app = resource_client.resources.get_by_id(
                resource_id=f"/subscriptions/3a1028f0-1402-44f3-b28a-bb2d76df1876/resourceGroups/{resource_group_name(ent['Name'], uid)}/providers/Microsoft.App/containerApps/{appName(ent['Name'],uid)}",
                api_version="2024-10-02-preview",
            ).as_dict()
            ent["provisioningState"] = app["properties"]["provisioningState"]
            ent["status"] = app["properties"]["runningStatus"]
            ent["images"] = [
                img["image"] for img in app["properties"]["template"]["containers"]
            ]
        except ResourceNotFoundError:
            ent["provisioningState"] = "Not provisioned yet"
            ent["status"] = "NA"
            ent["images"] = []
        except HttpResponseError:
            ent["provisioningState"] = "Missing!"
            ent["status"] = "Missing!"
            ent["images"] = []
    return [
        {
            "PartitionKey": x["PartitionKey"],
            "RowKey": x["RowKey"],
            "type": x["type"],
            "config": json.loads(x["Config"]),
            "name": x.get("Name", ""),
            "deployments": json.loads(x["Deployments"]),
            "provisioningState": x["provisioningState"],
            "status": x["status"],
            "images": x["images"],
        }
        for x in entities
    ]


@app.put("/service")
def put_service(uid: int, service_specification: ServiceSpecification = Body(...)):
    try:
        print(service_specification)
        table_client.create_entity(
            entity={
                "PartitionKey": str(uuid4()),
                "RowKey": str(uuid4()),
                "uid": uid,
                "type": service_specification.type.name,
                "Config": service_specification.config.model_dump_json(),
                "Name": service_specification.name,
                "Deployments": "[]",
            }
        )
        return "OK"
    except Exception as e:
        raise HTTPException(status_code=500, detail=traceback.format_exc())


@app.delete("/service")
def delete_service(RowKey: str, partKey: str):
    table_client.delete_entity(entity={"PartitionKey": partKey, "RowKey": RowKey})
    return "OK"


@app.get("/run_pipeline")
def run_pipeline(RowKey: str, partKey: str):
    entity = table_client.get_entity(partition_key=partKey, row_key=RowKey)
    config = entity.get("Config")
    name: str = entity.get("Name")
    # API endpoint
    url = f"https://dev.azure.com/{ORGANIZATION}/{project}/_apis/pipelines/{pipeline_id}/runs?api-version=7.1-preview.1"

    # Headers
    headers = {
        "Content-Type": "application/json",
    }

    # Optional body for parameters (e.g., pipeline variables)
    payload = {
        "resources": {
            "repositories": {
                "self": {"refName": "refs/heads/main"}  # Specify branch (e.g., 'main')
            }
        },
        "templateParameters": {  # Pass any template parameters your pipeline expects
            "config": config,
            "uid": entity["uid"],
            "name": name,
        },
    }

    # Trigger the pipeline
    response = requests.post(
        url, headers=headers, json=payload, auth=HTTPBasicAuth("", PIPELINE_PAT)
    )

    # Check response
    if response.status_code == 200 or response.status_code == 201:
        entity["Deployments"] = json.dumps(
            json.loads(entity.get("Deployments"))
            + [json.loads(response.content.decode("utf-8"))["id"]]
        )
        merged_entity = table_client.upsert_entity(mode=UpdateMode.MERGE, entity=entity)

        print("Pipeline triggered successfully!")
        return response.json()  # Details of the run
    else:
        print("Failed to trigger pipeline")
        print(f"Status code: {response.status_code}")
        return response.content


@app.get("/list_tags")
def list_tags(repository: str):
    try:
        # Get the list of tags
        tags = client.list_tag_properties(repository)
        tag_list = [tag.name for tag in tags]
        return {"tags": tag_list}
    except Exception as e:
        print(f"Failed to retrieve tags: {e}")
        return {"error": str(e)}


@app.get("/costs", response_model=float)
def get_costs(uid: int, appName: str):
    ResourceGroupName=f"rg_{appName}_{uid}"
    SubscriptionID="3a1028f0-1402-44f3-b28a-bb2d76df1876"
    time_period_in_past=30
    maxDateInPast = ((datetime.now(timezone.utc))-timedelta(days=time_period_in_past))
    time_period=QueryTimePeriod(from_property=maxDateInPast, to=datetime.now(timezone.utc))

    query_aggregation = dict()
    query_aggregation["totalCost"] = QueryAggregation(name="Cost", function="Sum")
    query_aggregation["totalCostUSD"] = QueryAggregation(name="CostUSD", function="Sum") 
    query_grouping = [QueryGrouping(type="Dimension", name="ResourceId"), QueryGrouping(type="Dimension", name="ChargeType"),
                        QueryGrouping(type="Dimension", name="PublisherType")]
    #query_filtering = QueryFilter(dimensions=QueryComparisonExpression(name="ResourceGuid", operator="In", values=[guid]))

    querydataset = QueryDataset(granularity=None, configuration=None, aggregation=query_aggregation, grouping=query_grouping)#, filter=query_filtering)
    query = QueryDefinition(type="ActualCost", timeframe="Custom", time_period=time_period, dataset=querydataset)
    scope = f'/subscriptions/{SubscriptionID}/resourceGroups/{ResourceGroupName}'

    result = cost_client.query.usage(scope = scope, parameters=query)


    cost_sum = 0
    for row in result.as_dict()['rows']:
        cost_sum += row[1]
    return cost_sum
