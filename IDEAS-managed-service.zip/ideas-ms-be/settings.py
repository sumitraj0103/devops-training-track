ORGANIZATION="raboweb"
project="51cc9317-c550-4d26-91e6-b32dc246f6e2"
pipeline_id="73353"
subscription="3a1028f0-1402-44f3-b28a-bb2d76df1876"

# Azure Container Registry details
registry_url = "https://testazcrreadrobin.azurecr.io"