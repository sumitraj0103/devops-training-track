from enum import Enum
from pydantic import BaseModel, Field, constr
from typing import List, Optional, Literal, Union


class ConfigField(BaseModel):
    name: str
    type: str
    description: str


class ConfigClass(BaseModel):
    name: str
    description: str


class ConfigRequirement(BaseModel):
    name: str
    description: str


class ExtractionConfig(BaseModel):
    documentType: str
    fields: Optional[List[ConfigField]]
    type: Literal['extraction'] = 'extraction'


class ClassificationConfig(BaseModel):
    classes: Optional[List[ConfigClass]]
    type: Literal['classification'] = 'classification'


class ValidationConfig(BaseModel):
    documentType: str
    requirements: Optional[List[ConfigRequirement]]
    type: Literal['validation'] = 'validation'


class ServiceTypeEnum(str, Enum):
    classification = 'classification'
    extraction = 'extraction'
    validation = 'validation'


class ServiceSpecification(BaseModel):
    type: ServiceTypeEnum
    config: Union[
        ExtractionConfig,
        ClassificationConfig,
        ValidationConfig
    ] = Field(discriminator='type')
    name: constr(pattern=r'^[a-z0-9-]+$')


class ServiceModel(BaseModel):
    RowKey: str
    PartitionKey: str
    type: ServiceTypeEnum
    config: Union[
        ExtractionConfig,
        ClassificationConfig,
        ValidationConfig
    ] = Field(discriminator='type')
    name: constr(pattern=r'^[a-z0-9-]+$')
    deployments: List[int]
    provisioningState: str
    status: str
    images: List[str]
