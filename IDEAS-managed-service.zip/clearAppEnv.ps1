$env = Get-AzContainerAppManagedEnv -name appEnv -ResourceGroupName rg_robin

$apps = Get-AzContainerApp -ResourceGroupName rg_robin 

foreach ($app in $apps) {
    if( ($app.ManagedEnvironmentId -eq $env.Id) -and ($app.name -ne "ideas-ms-be") -and ($app.name -ne "ideas-ms-be-test") -and ($app.name -ne "ideas-ms-fe") -and ($app.name -ne "ideas-ms-fe-test")){
        Remove-AzContainerApp -InputObject $app
    }
}