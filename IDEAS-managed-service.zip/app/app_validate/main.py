import os
import sys

# Add the parent directory to the sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

from app.core.app import EVALUATION_TAG, AbstractApp
seed = 2


class ValidateApp(AbstractApp):
    def __init__(self, seed):
        super().__init__(seed=seed)
        self.system_prompt = None
        self.user_prompt = None

        # Define endpoints specific to ValidateApp
        self.app.post("/validate", response_model=self.DocumentDTO)(self.process)
        self.app.post("/evaluate_batch_file", tags=[EVALUATION_TAG])(self.batch_file_evaluate)
        self.app.post("/get_batch_performance", tags=[EVALUATION_TAG])(self.get_batch_performance)
    def build_prompts(self):
        """
        Build the system and user prompts based on the configuration.
        """
        system_prompt = f"You are a bank employee that checks whether {self.CONFIG['documentType']} meet specified formal requirements. You are very precise and thorough."

        system_prompt += """      
        ### Instruction
        You are provided with a salary slip. Check the following requirements for the document.

        ### Requirements to check\n"""

        system_prompt += "\n".join(
            [f" - {requirement['name']}: {requirement['description']}" for requirement in self.CONFIG["requirements"]]
        )

        system_prompt += """\n### Output format
        Format your response as a JSON object with the following keys and according to the format instructions for the values of each key. If the data is not available then return the value False.\n"""

        system_prompt += "\n".join([f" - {requirement['name']}: Boolean" for requirement in self.CONFIG["requirements"]])

        self.system_prompt = system_prompt
        self.user_prompt = self.CONFIG.get("additionalInstructions", "")

    def validate_config(self):
        """
        Validate the loaded configuration.
        """
        if not self.CONFIG or not isinstance(self.CONFIG, dict):
            raise ValueError("Configuration not loaded or invalid!")

        # Check if 'requirements' and 'documentType' keys exist and are not empty
        if "requirements" not in self.CONFIG or "documentType" not in self.CONFIG:
            raise ValueError("Invalid configuration: 'requirements' or 'documentType' keys are missing.")
        
        if not self.CONFIG["requirements"] or not self.CONFIG["documentType"]:
            raise ValueError("Invalid configuration: 'requirements' or 'documentType' keys are empty.")

app = ValidateApp(seed).app
