# from unittest.mock import patch
# import os
# from fastapi.testclient import TestClient
# from app.app_validate.main import app
#
# client = TestClient(app)
#
#
# @patch("app_extract.main.client.chat.completions.create")
# def test_extract_openai_error(mock_create):
#     mock_create.side_effect = Exception("Mocked OpenAI error")
#     file_path = os.path.join(os.path.dirname(__file__), "valid_document.pdf")
#     with open(file_path, "rb") as f:
#         response = client.post("/extract", files={"document": f})
#     assert response.status_code == 500
#     assert "Error processing request with OpenAI" in response.json()["detail"]
#
#
# @patch("app_extract.main.unpack.from_buffer")
# def test_extract_tika_error(mock_unpack):
#     mock_unpack.side_effect = Exception("Mocked Tika error")
#     file_path = os.path.join(os.path.dirname(__file__), "valid_document.pdf")
#     with open(file_path, "rb") as f:
#         response = client.post("/extract", files={"document": f})
#     assert response.status_code == 500
#     assert "Error processing document with Tika" in response.json()["detail"]
#
#
# def test_get_status():
#     response = client.get("/status")
#     assert response.status_code == 200
#     assert response.json() == "Not set!"


def test():
    assert 1 == 1
