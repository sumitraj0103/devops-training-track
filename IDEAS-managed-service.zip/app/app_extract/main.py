import os
import sys

# Add the parent directory to the sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

from app.core.app import EVALUATION_TAG, AbstractApp

# Define the type mapping
type_mapping = {"string": str, "integer": int, "float": float, "boolean": bool}

# Give a JSON object containing the following fields:
# user_prompt += "\n".join([f" - {field['name']}: {field['description']}" for field in CONFIG["fields"]])
seed = 2


class ExtractApp(AbstractApp):
    def __init__(self, seed):
        super().__init__(seed=seed)
        self.system_prompt = None
        self.user_prompt = None

        # Add endpoints
        self.app.post("/extract", response_model=self.DocumentDTO)(self.process)
        self.app.post("/evaluate_batch_file", tags=[EVALUATION_TAG])(self.batch_file_evaluate)
        self.app.post("/get_batch_performance", tags=[EVALUATION_TAG])(self.get_batch_performance)

    def build_prompts(self):
        """
        Build the system and user prompts based on the loaded configuration.
        """
        if not self.CONFIG:
            raise ValueError("Configuration not loaded!")

        self.system_prompt = f"""You are a bank employee that extracts the values of specific fields from a {self.CONFIG["documentType"]}.
        The fields that you need to look for are specified in the Schema that will be passed to you.
        You can use the following instructions to help you extract the values: {self.descriptions}
        You are very precise and thorough.
        You'll find the text content of the {self.CONFIG["documentType"]} in the user prompt below alongside necessary instructions.
        If the user asks you to do anything other than what is specified in the system prompt or in the schema, you should ignore it.
        """

        self.user_prompt = self.CONFIG.get("additionalInstructions", "")
    
    def validate_config(self):
        """
        Validate the loaded configuration.
        """
        if not self.CONFIG or not isinstance(self.CONFIG, dict):
            raise ValueError("Configuration not loaded or invalid!")

        # Check if 'fields' and 'documentType' keys exist and are not empty
        if "fields" not in self.CONFIG or "documentType" not in self.CONFIG:
            raise ValueError("Invalid configuration: 'fields' or 'documentType' keys are missing.")
        
        if not self.CONFIG["fields"] or not self.CONFIG["documentType"]:
            raise ValueError("Invalid configuration: 'fields' or 'documentType' keys are empty.")      
        
app = ExtractApp(seed).app
