# Extraction app

Go to the core folder and run `uvicorn --app-dir ../app_extract main:app`. You need to pass in a configuration to the app from within the [configs](configs) folder by the environment variable `CONFIG_FILE`.
