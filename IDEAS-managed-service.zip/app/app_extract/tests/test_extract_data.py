# import os
# import json
# import unittest
# from app.app_extract.main import extract
#
#
# class TestDocumentExtraction(unittest.TestCase):
#
#     @classmethod
#     def setUpClass(cls):
#         cls.results = []
#
#     def extract_and_compare(self, directory):
#
#         current_mistakes = 0  # mistakes of this particular run
#
#         with open(os.path.join(directory, 'labels.json'), 'r') as f:
#             self.ground_truth = json.load(f)
#
#         # Create a dictionary for quick lookup of ground truth by document name
#         self.ground_truth_dict = {doc['name']: doc['fields'] for doc in self.ground_truth['documents']}
#
#         for filename in os.listdir(directory):
#             file_path = os.path.join(directory, filename)
#             if os.path.isfile(file_path) and file_path.endswith('.pdf'):
#                 with open(file_path, 'rb') as file:
#                     document_content = file.read()
#                     response = extract(document_content)
#                     response = json.loads(response.body.decode('utf-8'))
#                     document_name = os.path.splitext(filename)[0]
#                     if document_name in self.ground_truth_dict:
#                         expected = self.ground_truth_dict[document_name]
#                         match = response == expected
#                         result = {
#                             'filename': filename,
#                             'response': response,
#                             'expected': expected,
#                             'match': match
#                         }
#                         current_mistakes += 1 if not match else 0
#                     else:
#                         result = {
#                             'filename': filename,
#                             'response': response,
#                             'expected': None,
#                             'match': False
#                         }
#                     self.results.append(result)
#
#         assert current_mistakes == 0, f"Number of errors for {directory}: {current_mistakes}"
#
#     def test_document_extraction(self):
#         self.extract_and_compare("../data/rabo-press-release")
#
#     def test_visual_document_extraction(self):
#         self.extract_and_compare("../data/rabo-press-release-visual")
#
#     @classmethod
#     def tearDownClass(cls):
#         def print_results(results):
#             for result in results:
#                 print(f"Output for {result['filename']}:")
#                 print(json.dumps(result['response'], indent=4))
#                 if result['expected'] is not None:
#                     print(f"Expected for {result['filename']}:")
#                     print(json.dumps(result['expected'], indent=4))
#                     print(f"Comparison for {result['filename']}:")
#                     print("Match" if result['match'] else "Mismatch")
#                 else:
#                     print(f"No ground truth available for {result['filename']}")
#                 print("\n" + "=" * 50 + "\n")
#
#         print_results(cls.results)

# if __name__ == "__main__":
#     unittest.main()


def test():
    assert 1 == 1
