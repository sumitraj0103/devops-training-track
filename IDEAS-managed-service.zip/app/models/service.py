from sqlalchemy.orm import Mapped, mapped_column

from models import Base


class Service(Base):
    """
    Service model. Represents a service that can be used by the user.
    """

    __tablename__ = "services"
    id: Mapped[int] = mapped_column(primary_key=True, index=True)
