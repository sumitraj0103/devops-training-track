from datetime import datetime
from typing import Optional

from pydantic import BaseModel
from sqlalchemy import (
    ForeignKey,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from models import Base


# Database Models
class File(Base):
    """
    File model. Represents a file uploaded by the user. A file is associated with a batch.
    """

    __tablename__ = "files"
    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    batches_id: Mapped[int] = mapped_column(ForeignKey("batches.id"))
    file_hash: Mapped[str] = mapped_column(nullable=False)
    results: Mapped[Optional[dict]] = mapped_column(nullable=True, type_=JSONB)
    upload_timestamp: Mapped[datetime] = mapped_column(default=datetime.utcnow)
    ground_truth_hash: Mapped[Optional[str]] = mapped_column(nullable=True)
    batch = relationship("Batch", back_populates="files")


# Pydantic Schemas
class FileCreate(BaseModel):
    """
    Pydantic schema for creating a file

    attributes:
    - batches_id: int
    - file_hash: str
    - results: Optional[dict]
    - ground_truth_hash: Optional[str]
    """

    batches_id: int
    file_hash: str
    results: Optional[dict] = None
    ground_truth_hash: Optional[str] = None


class FileGet(BaseModel):
    """
    Pydantic schema for getting a file

    attributes:
    - id: Optional[int]
    - file_hash: Optional[str]
    - batches_id: Optional[int]
    - ground_truth_hash: Optional[str]
    - status: Optional[str]
    - limit: Optional[int]
    - offset
    """

    id: Optional[int] = None
    file_hash: Optional[str] = None
    batches_id: Optional[int] = None
    ground_truth_hash: Optional[str] = None
    status: Optional[str] = None
    limit: Optional[int] = None
    offset: Optional[int] = None


class FileUpdate(BaseModel):
    """
    Pydantic schema for updating a file

    attributes:
    - batches_id: Optional[int]
    - file_hash: Optional[str]
    - results: Optional[dict]
    - ground_truth_hash: Optional[str]
    """

    batches_id: Optional[int] = None
    file_hash: Optional[str] = None
    results: Optional[dict] = None
    ground_truth_hash: Optional[str] = None


class FileResponse(FileCreate):
    """
    Pydantic schema for returning a file

    attributes:
    - id: int
    - upload_timestamp: datetime, timestamp is timezone-unaware
    """

    id: int
    upload_timestamp: datetime

    class Config:
        from_attributes = True
