from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from models import Base


# Database Models
class Batch(Base):
    """
    Batch model. Represents a batch of files uploaded by the user.
    A batch is a collection of files that are processed together.
    """

    __tablename__ = "batches"
    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    status: Mapped[str] = mapped_column(nullable=False)
    creation_timestamp: Mapped[datetime] = mapped_column(
        default=lambda: datetime.utcnow().replace(tzinfo=None)
    )
    finish_timestamp: Mapped[Optional[datetime]] = mapped_column(
        default=lambda: datetime.utcnow().replace(tzinfo=None), nullable=True
    )
    results: Mapped[Optional[dict]] = mapped_column(nullable=True, type_=JSONB)
    files = relationship("File", back_populates="batch", cascade="all, delete-orphan")


# Pydantic Schemas
class BatchCreate(BaseModel):
    """
    Pydantic schema for creating a batch.

    attributes:
    - status: str
    - results: Optional[dict]
    - creation_timestamp: datetime, timestamp is timezone-unaware
    - finish_timestamp: Optional[datetime], timestamp is timezone-unaware
    """

    status: str
    creation_timestamp: Optional[datetime] = datetime.utcnow().replace(tzinfo=None)
    finish_timestamp: Optional[datetime] = Field(
        default=None, examples=["2025-03-27T09:47:09.599575"]
    )
    results: Optional[dict] = None


class BatchUpdate(BaseModel):
    """
    Pydantic schema for updating a batch.

    attributes:
    - status: Optional[str]
    - finish_timestamp: Optional[datetime], timestamp is timezone-unaware
    - results: Optional[dict]
    """

    status: Optional[str] = None
    finish_timestamp: Optional[datetime] = None
    results: Optional[dict] = None


class BatchResponse(BatchCreate):
    """
    Pydantic schema for returning a batch.

    attributes:
    - id: int
    - creation_timestamp: datetime, timestamp is timezone-unaware
    - finish_timestamp: Optional[datetime], timestamp is timezone-unaware
    """

    id: int
    creation_timestamp: datetime = None
    finish_timestamp: Optional[datetime] = None

    class Config:
        from_attributes = True
