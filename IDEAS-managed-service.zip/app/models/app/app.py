from os import environ as env
from typing import List, Optional

from fastapi import Depends, FastAPI, HTTPException, Query
from sqlalchemy import (
    create_engine,
)
from sqlalchemy.orm import Session, sessionmaker

from models import (
    Batch,
    BatchCreate,
    BatchResponse,
    File,
    FileCreate,
    FileResponse,
)

DATABASE_URL = env.get(
    "DATABASE_URL", "postgresql://postgres:postgres@localhost:5432/postgres"
)
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)


# Dependency
async def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


app = FastAPI()


# CRUD Endpoints
@app.post("/batches/", response_model=BatchResponse)
def create_batch(batch: BatchCreate, db: Session = Depends(get_db)):
    db_batch = Batch(status=batch.status, results=batch.results)
    db.add(db_batch)
    db.commit()
    db.refresh(db_batch)
    return db_batch


@app.get("/batches/{batch_id}", response_model=BatchResponse)
def get_batch(batch_id: int, db: Session = Depends(get_db)):
    batch = db.query(Batch).filter(Batch.id == batch_id).first()
    if batch is None:
        raise HTTPException(status_code=404, detail="Batch not found")
    return batch


@app.get("/batches", response_model=List[BatchResponse])
def get_all_batches(status: Optional[str] = Query(None), db: Session = Depends(get_db)):
    if status:
        return db.query(Batch).filter(Batch.status == status).all()
    return db.query(Batch).all()


@app.post("/files/", response_model=FileResponse)
def create_file(file: FileCreate, db: Session = Depends(get_db)):
    db_file = File(
        batches_id=file.batches_id,
        file_hash=file.file_hash,
        results=file.results,
        ground_truth_hash=file.ground_truth_hash,
    )
    db.add(db_file)
    db.commit()
    db.refresh(db_file)
    return db_file


@app.get("/files/{file_id}", response_model=FileResponse)
def get_file(file_id: int, db: Session = Depends(get_db)):
    file = db.query(File).filter(File.id == file_id).first()
    if file is None:
        raise HTTPException(status_code=404, detail="File not found")
    return file


@app.get("/files", response_model=List[BatchResponse])
def get_all_files(
    batch_id: Optional[int] = Query(None),
    file_hash: Optional[int] = Query(None),
    db: Session = Depends(get_db),
):
    query = db.query(File)
    if batch_id:
        return query.filter(File.batches_id == batch_id)
    if file_hash:
        return query.filter(File.file_hash == file_hash)
    return query.all()
