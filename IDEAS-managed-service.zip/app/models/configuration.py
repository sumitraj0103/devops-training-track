from typing import Optional, Dict, Any

from pydantic import BaseModel
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from models import Base


# Database Model
class Configuration(Base):
    """
    Configuration model. Represents a configuration entry in the database.
    Each configuration can store any arbitrary JSON structure.
    """

    __tablename__ = "configurations"
    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    config_data: Mapped[dict] = mapped_column(type_=JSONB, nullable=False)


# Pydantic Schemas
class ConfigurationCreate(BaseModel):
    """
    Pydantic schema for creating a configuration.

    attributes:
    - config_data: dict - Any valid JSON object
    """
    config_data: Dict[str, Any]


class ConfigurationUpdate(BaseModel):
    """
    Pydantic schema for updating a configuration.

    attributes:
    - config_data: Optional[dict] - Any valid JSON object
    """
    config_data: Optional[Dict[str, Any]] = None


class ConfigurationResponse(ConfigurationCreate):
    """
    Pydantic schema for returning a configuration.

    attributes:
    - id: int
    - config_data: dict
    """
    id: int

    class Config:
        from_attributes = True