from typing import List

from dto import (
    Base,
    BenchItem,
    BenchItemAggregate,
    BenchItemCreate,
    BenchItemResponse,
    BenchItemUpdate,
)
from fastapi import FastAPI, HTTPException
from sqlalchemy import Float, func
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.future import select
from sqlalchemy.orm import sessionmaker

DATABASE_URL = "postgresql+asyncpg://postgres:postgres@localhost:5432/postgres"

engine = create_async_engine(DATABASE_URL, echo=True)
SessionLocal = sessionmaker(
    autocommit=False, autoflush=False, bind=engine, class_=AsyncSession
)

app = FastAPI()


@app.on_event("startup")
async def startup():
    async with engine.begin() as conn:
        print("Creating tables")
        await conn.run_sync(Base.metadata.create_all)


@app.on_event("shutdown")
async def shutdown():
    await engine.dispose()


@app.post("/bench_items/", response_model=BenchItemResponse)
async def create_bench_item(item: BenchItemCreate):
    async with SessionLocal() as session:
        db_item = BenchItem(**item.dict())
        session.add(db_item)
        await session.commit()
        await session.refresh(db_item)
        return db_item


@app.get("/bench_items/", response_model=List[BenchItemResponse])
async def read_bench_items(skip: int = 0, limit: int = 10):
    async with SessionLocal() as session:
        result = await session.execute(select(BenchItem).offset(skip).limit(limit))
        items = result.scalars().all()
        return items


@app.get("/bench_items/{item_id}", response_model=BenchItemResponse)
async def read_bench_item(item_id: int):
    async with SessionLocal() as session:
        result = await session.execute(
            select(BenchItem).filter(BenchItem.id == item_id)
        )
        item = result.scalar_one_or_none()
        if item is None:
            raise HTTPException(status_code=404, detail="Item not found")
        return item


@app.put("/bench_items/{item_id}", response_model=BenchItemResponse)
async def update_bench_item(item_id: int, item: BenchItemUpdate):
    async with SessionLocal() as session:
        result = await session.execute(
            select(BenchItem).filter(BenchItem.id == item_id)
        )
        db_item = result.scalar_one_or_none()
        if db_item is None:
            raise HTTPException(status_code=404, detail="Item not found")
        item = item.dict(exclude_unset=True)
        for key, value in item.items():
            setattr(db_item, key, value)
        session.add(db_item)
        await session.commit()
        await session.refresh(db_item)
        return db_item


@app.delete("/bench_items/{item_id}", response_model=BenchItemResponse)
async def delete_bench_item(item_id: int):
    async with SessionLocal() as session:
        result = await session.execute(
            select(BenchItem).filter(BenchItem.id == item_id)
        )
        item = result.scalar_one_or_none()
        if item is None:
            raise HTTPException(status_code=404, detail="Item not found")
        await session.delete(item)
        await session.commit()
        return item


@app.get("/bench_items/aggregate/", response_model=List[BenchItemAggregate])
async def aggregate_bench_items():
    async with SessionLocal() as session:
        result = await session.execute(
            select(
                BenchItem.data["clientName"].label("clientName"),
                func.avg(BenchItem.data["value"].cast(Float)).label("total_value"),
            ).group_by("clientName")
        )
        aggregates = result.all()
        return [
            BenchItemAggregate(clientName=row.clientName, total_value=row.total_value)
            for row in aggregates
        ]
