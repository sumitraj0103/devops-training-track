import uuid as uuid_pkg
from datetime import datetime
from typing import Optional

from pydantic import BaseModel
from sqlalchemy import Column, DateTime, Integer, String
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()


class BenchItem(Base):
    __tablename__ = "bench_items"

    id = Column(Integer, primary_key=True, index=True)
    uuid = Column(UUID(as_uuid=True), default=uuid_pkg.uuid4, unique=True, index=True)
    name = Column(String, index=True)
    data = Column(JSONB)
    timestamp = Column(DateTime, default=datetime.utcnow)


class BenchItemCreate(BaseModel):
    name: str
    data: dict
    uuid: uuid_pkg.UUID = uuid_pkg.uuid4()
    timestamp: datetime = datetime.utcnow()


class BenchItemUpdate(BaseModel):
    name: Optional[str] = None
    data: Optional[dict] = None
    uuid: Optional[uuid_pkg.UUID] = None
    timestamp: Optional[datetime] = None


class BenchItemResponse(BaseModel):
    id: int
    uuid: Optional[uuid_pkg.UUID]
    name: Optional[str]
    data: Optional[dict]
    timestamp: Optional[datetime]

    class Config:
        orm_mode = True


class BenchItemAggregate(BaseModel):
    clientName: Optional[str]
    total_value: Optional[float]
