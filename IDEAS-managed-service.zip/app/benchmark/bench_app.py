import random
import uuid

from locust import FastHttpUser, between, task

randNames = [
    a + b for a in ["John", "Jane", "Alice", "Bob"] for b in ["Doe", "Smith", "Johnson"]
]


def nextName():
    return random.choice(randNames)


class BenchItemLoadTest(FastHttpUser):
    wait_time = between(0.01, 0.5)

    @task
    def create_bench_item(self):
        self.client.post(
            "/bench_items/",
            json={
                "name": "Test Item",
                "data": {
                    "clientName": nextName(),
                    "value": random.randint(100, 1000) / 10,
                },
                "uuid": str(uuid.uuid4()),
            },
        )

    @task
    def crud_bench_item(self):
        response = self.client.post(
            "/bench_items/",
            json={
                "name": "Test Item",
                "data": {
                    "clientName": nextName(),
                    "value": random.randint(100, 1000) / 10,
                },
                "uuid": str(uuid.uuid4()),
            },
        )
        if response.status_code == 200:
            item_id = response.json()["id"]
            self.read_bench_item(item_id)
            self.update_bench_item(item_id)
            self.delete_bench_item(item_id)

    @task
    def read_bench_items(self):
        self.client.get("/bench_items/")

    def read_bench_item(self, item_id):
        self.client.get(f"/bench_items/{item_id}/", name="/bench_items/{item_id}")

    def update_bench_item(self, item_id):
        self.client.put(
            f"/bench_items/{item_id}/",
            json={
                "name": "Updated Test Item",
                "uuid": str(uuid.uuid4()),
                "timestamp": "2023-10-10T10:10:10",
            },
            name="/bench_items/{item_id}",
        )

    def delete_bench_item(self, item_id):
        self.client.delete(f"/bench_items/{item_id}/", name="/bench_items/{item_id}")

    @task
    def aggregate_bench_items(self):
        self.client.get("/bench_items/aggregate/")
