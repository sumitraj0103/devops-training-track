from typing import List

from dto import (
    Base,
    BenchItem,
    BenchItemAggregate,
    BenchItemCreate,
    BenchItemResponse,
    BenchItemUpdate,
)
from fastapi import FastAPI, HTTPException
from sqlalchemy import Float, create_engine, func
from sqlalchemy.future import select
from sqlalchemy.orm import sessionmaker

DATABASE_URL = "postgresql://postgres:postgres@localhost:5432/postgres"

engine = create_engine(DATABASE_URL, echo=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

app = FastAPI()


@app.on_event("startup")
def startup():
    Base.metadata.create_all(bind=engine)


@app.on_event("shutdown")
def shutdown():
    engine.dispose()


@app.post("/bench_items/", response_model=BenchItemResponse)
def create_bench_item(item: BenchItemCreate):
    with SessionLocal() as session:
        db_item = BenchItem(**item.dict())
        session.add(db_item)
        session.commit()
        session.refresh(db_item)
        return db_item


@app.get("/bench_items/", response_model=List[BenchItemResponse])
def read_bench_items(skip: int = 0, limit: int = 10):
    with SessionLocal() as session:
        result = session.execute(select(BenchItem).offset(skip).limit(limit))
        items = result.scalars().all()
        return items


@app.get("/bench_items/{item_id}", response_model=BenchItemResponse)
def read_bench_item(item_id: int):
    with SessionLocal() as session:
        result = session.execute(select(BenchItem).filter(BenchItem.id == item_id))
        item = result.scalar_one_or_none()
        if item is None:
            raise HTTPException(status_code=404, detail="Item not found")
        return item


@app.put("/bench_items/{item_id}", response_model=BenchItemResponse)
def update_bench_item(item_id: int, item: BenchItemUpdate):
    with SessionLocal() as session:
        result = session.execute(select(BenchItem).filter(BenchItem.id == item_id))
        db_item = result.scalar_one_or_none()
        if db_item is None:
            raise HTTPException(status_code=404, detail="Item not found")
        item = item.dict(exclude_unset=True)
        for key, value in item.items():
            setattr(db_item, key, value)
        session.add(db_item)
        session.commit()
        session.refresh(db_item)
        return db_item


@app.delete("/bench_items/{item_id}", response_model=BenchItemResponse)
def delete_bench_item(item_id: int):
    with SessionLocal() as session:
        result = session.execute(select(BenchItem).filter(BenchItem.id == item_id))
        item = result.scalar_one_or_none()
        if item is None:
            raise HTTPException(status_code=404, detail="Item not found")
        session.delete(item)
        session.commit()
        return item


@app.get("/bench_items/aggregate/", response_model=List[BenchItemAggregate])
def aggregate_bench_items():
    with SessionLocal() as session:
        result = session.execute(
            select(
                BenchItem.data["clientName"].label("clientName"),
                func.avg(BenchItem.data["value"].cast(Float)).label("total_value"),
            ).group_by("clientName")
        )
        aggregates = result.all()
        return [
            BenchItemAggregate(clientName=row.clientName, total_value=row.total_value)
            for row in aggregates
        ]
