import pytest
from httpx import ASGITransport, AsyncClient
from core.app import AbstractApp


class MockApp(AbstractApp):
    """
    Mock implementation of AbstractApp for testing purposes.
    """

    def __init__(self, seed=0):
        super().__init__(seed=seed)

    def build_prompts(self):
        """
        Mock implementation of the abstract method.
        """
        self.system_prompt = "Mock system prompt."
        self.user_prompt = "Mock user prompt."

    def validate_config(self):
        """
        Mock implementation of the abstract method.
        """
        # For testing purposes, assume the configuration is always valid
        if not self.CONFIG or not isinstance(self.CONFIG, dict):
            raise ValueError("Mock configuration is invalid!")


# Use the mock implementation of AbstractApp
app = MockApp(seed=0)


@pytest.fixture
def anyio_backend():
    return "asyncio"


@pytest.fixture()
async def async_client():
    async with AsyncClient(
        transport=ASGITransport(app=app.app), base_url="http://test"
    ) as ac:
        yield ac


@pytest.mark.anyio
async def test_ping(async_client):
    response = await async_client.get("/ping")
    assert "pong" in response.text


@pytest.mark.anyio
async def test_get_prompt(async_client):
    response = await async_client.get("/prompt")
    assert response.status_code == 200
    assert "system_prompt" in response.json()
    assert "user_prompt" in response.json()


@pytest.mark.anyio
async def test_get_status(async_client):
    response = await async_client.get("/status")
    assert response.status_code == 200
    assert response.text == '"Not set!"'


@pytest.mark.anyio
async def test_create_batch(async_client):
    batch_data = {
        "status": "completed",
        "results": {"field1": "value1"},
        "creation_timestamp": "2023-01-01T00:00:00",
        "finish_timestamp": "2023-01-01T01:00:00",
    }
    response = await async_client.post("/batches/", json=batch_data)
    assert response.status_code == 200
    response_json = response.json()
    assert response_json["status"] == "completed"
    assert response_json["results"]["field1"] == "value1"
    assert response_json["creation_timestamp"] == "2023-01-01T00:00:00"
    assert response_json["finish_timestamp"] == "2023-01-01T01:00:00"
    assert "id" in response_json


@pytest.mark.anyio
async def test_get_batch(async_client):
    batch_data = {
        "status": "completed",
        "results": {"field1": "value1"},
        "creation_timestamp": "2023-01-01T00:00:00",
        "finish_timestamp": "2023-01-01T01:00:00",
    }
    create_response = await async_client.post("/batches/", json=batch_data)
    assert create_response.status_code == 200
    batch_id = create_response.json()["id"]

    response = await async_client.get(f"/batches/{batch_id}")
    assert response.status_code == 200
    assert response.json()["id"] == batch_id

    response = await async_client.get("/batches/-1")
    assert response.status_code == 404  # Assuming batch with ID -1 does not exist


@pytest.mark.anyio
async def test_get_all_batches(async_client):
    response = await async_client.get("/batches")
    assert response.status_code == 200
    assert isinstance(response.json(), list)


@pytest.mark.anyio
async def test_update_batch(async_client):
    batch_data = {
        "status": "completed",
        "results": {"field1": "value1"},
        "creation_timestamp": "2023-01-01T00:00:00",
        "finish_timestamp": "2023-01-01T01:00:00",
    }
    create_response = await async_client.post("/batches/", json=batch_data)
    assert create_response.status_code == 200
    batch_id = create_response.json()["id"]

    updated_data = {
        "status": "updated_status",
        "results": {"field1": "updated_value"},
        "finish_timestamp": "2023-01-01T02:00:00",
    }
    response = await async_client.put(f"/batches/{batch_id}", json=updated_data)
    assert response.status_code == 200
    response_json = response.json()
    assert response_json["status"] == "updated_status"
    assert response_json["results"]["field1"] == "updated_value"
    assert response_json["finish_timestamp"] == "2023-01-01T02:00:00"


@pytest.mark.anyio
async def test_delete_batch(async_client):
    batch_data = {
        "status": "completed",
        "results": {"field1": "value1"},
        "creation_timestamp": "2023-01-01T00:00:00",
        "finish_timestamp": "2023-01-01T01:00:00",
    }
    create_response = await async_client.post("/batches/", json=batch_data)
    assert create_response.status_code == 200
    batch_id = create_response.json()["id"]

    response = await async_client.delete(f"/batches/{batch_id}")
    assert response.status_code == 200

    response = await async_client.delete("/batches/-1")
    assert response.status_code == 404  # Assuming batch with ID -1 does not exist


@pytest.mark.anyio
async def test_get_config(async_client):
    response = await async_client.get("/configurations")
    assert response.status_code == 200
    assert isinstance(response.json(), list)  # Expecting a list of configurations


@pytest.mark.anyio
async def test_create_file(async_client):
    file_data = {
        "batches_id": 2,
        "file_hash": "abc123",
        "results": {},
        "ground_truth_hash": "def456",
    }
    response = await async_client.post("/files/", json=file_data)
    assert response.status_code == 200
    response_json = response.json()
    assert response_json["batches_id"] == 2
    assert response_json["file_hash"] == "abc123"
    assert response_json["ground_truth_hash"] == "def456"
    assert "id" in response_json  # Ensure the response contains a file ID
    assert "upload_timestamp" in response_json  # Ensure the response contains a timestamp


@pytest.mark.anyio
async def test_get_file(async_client):
    file_data = {
        "batches_id": 2,
        "file_hash": "abc123",
        "results": {},
        "ground_truth_hash": "def456",
    }
    create_response = await async_client.post("/files/", json=file_data)
    assert create_response.status_code == 200
    file_id = create_response.json()["id"]

    response = await async_client.get(f"/files/{file_id}")
    assert response.status_code == 200
    response_json = response.json()
    assert response_json["id"] == file_id
    assert response_json["batches_id"] == 2
    assert response_json["file_hash"] == "abc123"
    assert response_json["ground_truth_hash"] == "def456"
    assert "upload_timestamp" in response_json


@pytest.mark.anyio
async def test_delete_file(async_client):
    file_data = {
        "batches_id": 2,
        "file_hash": "abc123",
        "results": {},
        "ground_truth_hash": "def456",
    }
    create_response = await async_client.post("/files/", json=file_data)
    assert create_response.status_code == 200
    file_id = create_response.json()["id"]

    # Delete the file using only the file ID
    response = await async_client.delete(f"/files/{file_id}")
    assert response.status_code == 200

    # Attempt to delete a non-existent file
    response = await async_client.delete("/files/-1")
    assert response.status_code == 404  # Assuming file with ID -1 does not exist

@pytest.mark.anyio
async def test_validate_config():
    app = MockApp(seed=0)
    app.CONFIG = {"documentType": "TestDocument", "fields": []}
    try:
        app.validate_config()
    except ValueError as e:
        pytest.fail(f"validate_config raised an unexpected error: {e}")