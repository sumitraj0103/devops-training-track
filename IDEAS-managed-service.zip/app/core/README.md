# IDEAS App Core

### Setting up environment variables

Create .env file with content:
```
AZURE_OPENAI_ENDPOINT=<url>
ADI_ENDPOINT=<url>
appname=IDEAS
```

Create OPENAI_KEY.secret file with content:
`AZURE_OPENAI_KEY=<api key>`

Create ADI_KEY.secret file with content:
`ADI_KEY=<api key>`

### Installation and running

1. Open terminal in app folder 
2. Run
`poetry install`
3. And afterwards run
`uvicorn main:app`

### How to run Tika Java server locally

1. Install Tesseract: https://cwiki.apache.org/confluence/display/TIKA/TikaOCR

2. Run `java -jar tika-server.jar -config tika-config.xml`

> Copied tika-config.xml from https://stackoverflow.com/a/60404894