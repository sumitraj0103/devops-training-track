import json
import logging
import os
from abc import ABC, abstractmethod
from hashlib import sha1
from os import environ as env
from typing import Annotated, List, Optional
from pydantic import create_model

from dotenv import load_dotenv
from fastapi import (
    Depends,
    FastAPI,
    File,
    Header,
    HTTPException,
    UploadFile,
)
from fastapi.middleware.cors import CORSMiddleware
from openai import AsyncAzureOpenAI as AzureOpenAI
from sqlalchemy.ext.asyncio import AsyncSession
from starlette.responses import JSONResponse

import core.utils.crud_operations as crud_operations
from core.services.adi_service import ADIService
from core.utils.evaluation_utils import compare_json
from core.utils.tika import tika_parse
from models import (
    BatchResponse,
    FileCreate,
    FileGet,
    FileResponse,
    ConfigurationResponse,
)

load_dotenv(os.path.join(os.path.dirname(__file__), ".env"))
load_dotenv(os.path.join(os.path.dirname(__file__), "OPENAI_KEY.secret"))
load_dotenv(os.path.join(os.path.dirname(__file__), "ADI_KEY.secret"))

logger = logging.getLogger(__name__)
type_mapping = {"string": str, "integer": int, "float": float, "boolean": bool}
# Database configuration
DATABASE_URL = env.get(
    "DATABASE_URL", "postgresql+asyncpg://postgres:postgres@localhost:5432/postgres"
)

# Tags
EVALUATION_TAG = "evaluation"
BATCHES_TAG = "batches"
FILES_TAG = "files"
CONFIGURATIONS_TAG = "configurations"


class AbstractApp(ABC):
    """
    Abstract class for the FastAPI application.

    This class provides the basic structure for the FastAPI application, including the endpoints for the batch and file
    management, as well as the performance evaluation.

    The class is designed to be extended by the specific application, which should provide the system and user prompts
    to be used in the OpenAI API, as well as the field names for the batch performance.
    """

    def __init__(
        self,
        seed: Optional[int] = 0,
    ):
        self._field_names = None
        self.fields = None
        self.descriptions = None
        self.DocumentDTO = None
        self.seed = seed
        self.CONFIG = {
            "documentType": "DefaultDocument",
            "fields": [],
            "additionalInstructions": ""
        }  # Default configuration
        self.system_prompt = "Default system prompt."
        self.user_prompt = "Default user prompt."

        self.app = FastAPI(title=os.getenv("appname", "Name not set!"))
        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

        self.TIKA_SERVER = os.getenv("TIKA_SERVER", "http://localhost:9998")
        self.TEMPERATURE = 0.0

        self.AZURE_OPENAI_KEY = os.getenv("AZURE_OPENAI_KEY")
        self.AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
        self.deployment_name = "gpt-4o"

        self.client = AzureOpenAI(
            api_key=self.AZURE_OPENAI_KEY,
            api_version="2024-12-01-preview",
            azure_endpoint=self.AZURE_OPENAI_ENDPOINT,
        )

        # Endpoints
        self.app.get("/prompt")(self.get_prompt)
        self.app.get("/status")(self.get_services)
        self.app.get("/ping")(AbstractApp.get_ping)
        self.app.post("/get_batch_performance", tags=[EVALUATION_TAG])(
            self.get_batch_performance
        )

        # Batches endpoints
        self.app.post("/batches/", response_model=BatchResponse, tags=[BATCHES_TAG])(
            crud_operations.create_batch
        )
        self.app.get(
            "/batches/{batch_id}", response_model=BatchResponse, tags=[BATCHES_TAG]
        )(crud_operations.get_batch)
        self.app.get(
            "/batches", response_model=List[BatchResponse], tags=[BATCHES_TAG]
        )(crud_operations.get_all_batches)
        self.app.delete(
            "/batches/{batch_id}", response_model=BatchResponse, tags=[BATCHES_TAG]
        )(crud_operations.delete_batch)
        self.app.put(
            "/batches/{batch_id}", response_model=BatchResponse, tags=[BATCHES_TAG]
        )(crud_operations.update_batch)

        # Files endpoints
        self.app.post("/files/", response_model=FileResponse, tags=[FILES_TAG])(
            crud_operations.create_file
        )
        self.app.get("/files/{file_id}", response_model=FileResponse, tags=[FILES_TAG])(
            crud_operations.get_file
        )
        self.app.get("/files", response_model=List[FileResponse], tags=[FILES_TAG])(
            crud_operations.get_all_files
        )
        self.app.delete(
            "/files/{file_id}", response_model=FileResponse, tags=[FILES_TAG]
        )(crud_operations.delete_file)
        self.app.put("/files/{file_id}", response_model=FileResponse, tags=[FILES_TAG])(
            crud_operations.update_file
        )

        # Configuration endpoints
        self.app.post("/configurations/", response_model=ConfigurationResponse, tags=[CONFIGURATIONS_TAG])(crud_operations.create_configuration)
        self.app.get("/configurations/{config_id}", response_model=ConfigurationResponse, tags=[CONFIGURATIONS_TAG])(crud_operations.get_configuration)
        self.app.get("/configurations", response_model=List[ConfigurationResponse], tags=[CONFIGURATIONS_TAG])(crud_operations.get_all_configurations)
        self.app.delete("/configurations/{config_id}", response_model=ConfigurationResponse, tags=[CONFIGURATIONS_TAG])(crud_operations.delete_configuration)
        self.app.post("/set_config", tags=["configurations"])(self.set_config_endpoint)

        endpoint = os.getenv("ADI_ENDPOINT")
        key = os.getenv("ADI_KEY")
        if endpoint and key:
            self.adi_service = ADIService(endpoint, key)

    @property
    def evaluation_keys(self):
        return self._field_names

    @property
    def output_schema(self):
        return self.DocumentDTO.model_json_schema()

    async def set_config_endpoint(
        self,
        config_id: int,
        db: AsyncSession = Depends(crud_operations.get_db),
    ):
        """
        Endpoint to set the configuration for the application dynamically.
        """
        print(f"Received config_id: {config_id}")
        config = await crud_operations.get_configuration(config_id, db)
        print(f"Loaded configuration: {config}")
        if not config:
            raise HTTPException(status_code=404, detail="Configuration not found")

        # Ensure the config is in a dictionary format
        if hasattr(config, "config_data") and isinstance(config.config_data, dict):
            config = config.config_data
        else:
            raise HTTPException(
                status_code=400,
                detail="Invalid configuration format: 'config_data' is missing or not a dictionary.",
            )

        # Dynamically handle varying key names
        self.CONFIG = config
        self.fields = {}
        self.field_names = []
        self.descriptions = {}

        # Handle "fields" or equivalent key dynamically
        fields_key = next((key for key in config if key.lower() == "fields"), None)
        if fields_key:
            self.fields = {
                field["name"]: (type_mapping.get(field["type"], str), ...)
                for field in config[fields_key]
            }
            self.field_names = [field["name"] for field in config[fields_key]]
            self.descriptions = {
                field["name"]: field.get("description", "No description provided.")
                for field in config[fields_key]
            }

        # Dynamically create the DocumentDTO model
        if self.fields:
            self.DocumentDTO = create_model("DocumentDTO", **self.fields)
        else:
            self.DocumentDTO = create_model("DocumentDTO")  # Empty model if no fields

        # Handle other keys dynamically (e.g., "documentType", "requirements")
        self.CONFIG["documentType"] = config.get("documentType", "DefaultDocument")
        self.CONFIG["requirements"] = config.get("requirements", [])
        self.CONFIG["additionalInstructions"] = config.get(
            "additionalInstructions", ""
        )

        # Validate the configuration
        try:
            self.validate_config()
        except ValueError as e:
            raise HTTPException(status_code=400, detail=f"Configuration validation failed: {str(e)}")

        # Call build_prompts to generate system and user prompts
        self.build_prompts()

        return {"message": "Configuration loaded and prompts built successfully"}

    @abstractmethod
    def build_prompts(self):
        """
        Abstract method for building system and user prompts.
        Must be implemented by the instantiated app.
        """
        pass

    @abstractmethod
    def validate_config(self):
        """
        Abstract method for validating the configuration.
        Must be implemented by the instantiated app.
        """
        pass

    async def get_services(self):
        return "Not set!"

    async def get_prompt(self):
        return {"system_prompt": self.system_prompt, "user_prompt": self.user_prompt}

    async def process(
        self,
        document: Annotated[UploadFile, File()],
        parser: Annotated[str | None, Header()] = "tika",
    ):
        """
        Process the uploaded document using the OpenAI API.
        """
        try:
            # Validate the configuration before processing
            self.validate_config()
        except ValueError as e:
            # Return a 400 Bad Request with the error message
            raise HTTPException(status_code=400, detail=str(e))

        document_content = await document.read()

        # Check if the file is .txt or .rtf and skip OCR if true
        if document.filename.endswith(".txt") or document.filename.endswith(".rtf"):
            content = document_content.decode("utf-8")
        else:
            try:
                match parser:
                    case "adi":
                        content = await self.adi_service.parse_async(document_content)
                    case _:
                        content = await tika_parse(document_content, self.TIKA_SERVER)
            except Exception as e:
                raise HTTPException(
                    status_code=500, detail=f"Error processing document: {str(e)}"
                )

        print(content)

        messages = [
            {"role": "system", "content": self.system_prompt},
            {"role": "user", "content": f"{self.user_prompt}\n{content}"},
        ]
        # Convert the DocumentDTO schema to JSON Schema
        document_dto_schema = self.output_schema
        document_dto_schema["name"] = "DocumentDTO"
        try:
            response = await self.client.chat.completions.create(
                model=self.deployment_name,
                messages=messages,
                response_format={
                    "type": "json_schema",
                    "json_schema": {
                        "name": "DocumentDTO",
                        "schema": document_dto_schema,
                    },
                },
                temperature=self.TEMPERATURE,
                seed=self.seed,
            )
        except Exception as e:
            raise HTTPException(
                status_code=500,
                detail=f"Error processing request with OpenAI: {str(e)}",
            )

        response_content = response.choices[0].message.content
        response_json = json.loads(response_content)
        return JSONResponse(content=response_json, media_type="application/json")

    async def get_batch_performance(
        self, batchID: int, db: AsyncSession = Depends(crud_operations.get_db)
    ):
        """
        Get the performance of a batch based on the stored results.
        A batch performance is calculated as the coefficient of true results for each field in the evaluation keys.

        :param batchID: The ID of the batch to evaluate.
        :return: The performance of the batch.
        """
        files = await crud_operations.file_repository.get_files(
            db, FileGet(batches_id=batchID)
        )
        batch_results = [r.results["comparison_result"] for r in files]

        # Initialize the performance dictionary
        performance = {field: {"true": 0, "false": 0} for field in self.evaluation_keys}

        if not self.evaluation_keys:
            raise NotImplementedError("Field names not set!")

        # Iterate through the stored results for the given batch ID
        for result in batch_results:
            for field in self.evaluation_keys:
                if field in result:
                    if result[field]["status"]:
                        performance[field]["true"] += 1
                    else:
                        performance[field]["false"] += 1

        # Calculate the coefficient of true/false for each field
        for field in performance:
            total = performance[field]["true"] + performance[field]["false"]
            if total > 0:
                performance[field]["coefficient"] = performance[field]["true"] / total
            else:
                performance[field]["coefficient"] = None

        # Prepare the result dictionary to match the DocumentDTO structure
        result = {
            field: performance[field]["coefficient"] for field in self.evaluation_keys
        }

        return JSONResponse(content=result, media_type="application/json")

    async def batch_file_evaluate(
        self,
        batchID,
        document: Annotated[UploadFile, File()],
        ground_truth: Annotated[UploadFile, File()],
        parser: Annotated[Optional[str], Header()] = "tika",
        db: AsyncSession = Depends(crud_operations.get_db),
    ):
        """
        Evaluate a file for a given batch based on the ground truth file.
        After evaluating the file, the results are stored in the database.

        :param batchID: The ID of the batch to evaluate the file for.
        :param document: The document file to evaluate.
        :param ground_truth: The ground truth file to compare the document against.
        :return: The evaluation results.
        """
        document_filename_hash = sha1(document.filename.encode()).hexdigest()
        ground_truth_filename_hash = sha1(ground_truth.filename.encode()).hexdigest()
        result = await self._batch_file_evaluate(
            batchID, document, ground_truth, parser
        )

        await crud_operations.file_repository.add_file(
            db,
            FileCreate(
                batches_id=batchID,
                file_hash=document_filename_hash,
                results=result,
                ground_truth_hash=ground_truth_filename_hash,
            ),
        )

        return JSONResponse(content=result, media_type="application/json")

    async def _batch_file_evaluate(
        self,
        batchID,
        document: Annotated[UploadFile, File()],
        ground_truth: Annotated[UploadFile, File()],
        parser: Optional[str] = "tika",
    ):
        # Read and parse the ground truth JSON file
        ground_truth_content = await ground_truth.read()
        try:
            ground_truth_json = json.loads(ground_truth_content)
        except json.JSONDecodeError as e:
            raise HTTPException(
                status_code=400, detail=f"Invalid JSON in ground truth file: {str(e)}"
            )

        # Call the process function to get the response for the uploaded PDF document
        response = await self.process(document, parser=parser)
        response_json = response.body.decode("utf-8")
        response_json = json.loads(response_json)

        # Compare the response with the ground truth JSON
        comparison_result = await compare_json(response_json, ground_truth_json)

        # Add batchID to the comparison result
        result = {"batchID": batchID, "comparison_result": comparison_result}
        return result

    @staticmethod
    def get_ping():
        return os.getenv("PINGMSG", "pong")
