import re


async def compare_json(response_json, ground_truth_json):
    comparison_result = {}
    overall_status = True

    # Function to normalize strings by removing spaces, dots, commas, and converting to lowercase
    def normalize_string(value):
        if isinstance(value, str):
            # Use regex to remove spaces, dots, commas, and other unwanted characters
            return re.sub(r"[ ,\.]", "", value).lower()
        return value

    for key in ground_truth_json:
        if key not in response_json:
            comparison_result[key] = {
                "status": False,
                "message": f"Key '{key}' missing in response",
            }
            overall_status = False
        else:
            # Normalize strings before comparison
            response_value = normalize_string(response_json[key])
            ground_truth_value = normalize_string(ground_truth_json[key])

            if response_value != ground_truth_value:
                comparison_result[key] = {
                    "status": False,
                    "message": f"Value for key '{key}' differs: response '{response_json[key]}' vs ground truth '{ground_truth_json[key]}'",
                }
                overall_status = False
            else:
                comparison_result[key] = {"status": True, "message": "Match"}

    comparison_result["overall_status"] = overall_status
    return comparison_result
