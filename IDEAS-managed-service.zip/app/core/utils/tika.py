import asyncio

from fastapi import HTTPException
from tika import unpack


async def tika_parse(document: bytes, TIKA_SERVER) -> dict:
    try:
        content = await asyncio.get_event_loop().run_in_executor(
            None,
            unpack.from_buffer,
            document,
            TIKA_SERVER,
            {"timeout": 300},
        )
        content = content["content"]
    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Error processing document with Tika: {str(e)}"
        )
    return content
