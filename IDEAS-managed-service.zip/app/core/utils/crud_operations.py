import logging
import os
from collections.abc import AsyncGenerator
from os import environ as env
from typing import Optional

from dotenv import load_dotenv
from fastapi import Depends, HTTPException, Query
from sqlalchemy import exc
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from models import (
    BatchCreate,
    BatchUpdate,
    FileCreate,
    FileGet,
    FileUpdate,
    ConfigurationCreate,
    ConfigurationUpdate,
)
from repository import BatchRepository, FileRepository, ConfigurationRepository

load_dotenv(os.path.join(os.path.dirname(__file__), ".env"))
load_dotenv(os.path.join(os.path.dirname(__file__), "OPENAI_KEY.secret"))

logger = logging.getLogger(__name__)
# Database configuration
DATABASE_URL = env.get(
    "DATABASE_URL", "postgresql+asyncpg://postgres:postgres@localhost:5432/postgres"
)


# Repositories
batch_repository = BatchRepository()
file_repository = FileRepository()
configuration_repository = ConfigurationRepository()


# Dependency for the database session
async def get_db() -> AsyncGenerator[AsyncSession, None]:
    engine = create_async_engine(DATABASE_URL)
    factory = async_sessionmaker(engine)
    async with factory() as session:
        try:
            yield session
            await session.commit()
        except exc.SQLAlchemyError as e:
            logger.error(f"Error in database session: {str(e)}")
            await session.rollback()
            raise


# Batch endpoints
async def create_batch(batch: BatchCreate, db: AsyncSession = Depends(get_db)):
    """
    Create a new batch in the database.

    :param batch: The batch data to be stored in the database.
    :return: The created batch data.
    """
    return await batch_repository.create_batch(db, batch)


async def get_batch(batch_id: int, db: AsyncSession = Depends(get_db)):
    """
    Get a batch by its ID from the database.

    :param batch_id: The ID of the batch to retrieve.
    :return: The batch data.
    """
    batch = await batch_repository.get_batch_by_id(db, batch_id)
    if batch is None:
        raise HTTPException(status_code=404, detail="Batch not found")
    return batch


async def get_all_batches(
    status: Optional[str] = Query(None), db: AsyncSession = Depends(get_db)
):
    """
    Get all batches from the database.

    :param status: The status of the batches to retrieve.
    :return: A list of batch data.
    """
    return await batch_repository.get_all_batches(db, status=status)


async def delete_batch(batch_id: int, db: AsyncSession = Depends(get_db)):
    """
    Delete a batch by its ID from the database.

    :param batch_id: The ID of the batch to delete.
    :return: The deleted batch data.
    """
    batch = await batch_repository.get_batch_by_id(db, batch_id)
    if batch is None:
        raise HTTPException(status_code=404, detail="Batch not found")
    await batch_repository.delete_batch(db, batch_id)
    return batch


async def update_batch(
    batch_id: int, batch_data: BatchUpdate, db: AsyncSession = Depends(get_db)
):
    """
    Update a batch by its ID in the database.

    :param batch_id: The ID of the batch to update.
    :param batch_data: The updated batch data.
    :return: The updated batch data.
    """
    batch = await batch_repository.update_batch_by_id(db, batch_id, batch_data)
    if batch is None:
        raise HTTPException(status_code=404, detail="Batch not found")
    return batch


# File endpoints
async def create_file(file: FileCreate, db: AsyncSession = Depends(get_db)):
    """
    Create a new file in the database.

    :param file: The file data to be stored in the database.
    :return: The created file data.
    """
    return await file_repository.add_file(db, file)


async def get_all_files(
    file_filter: FileGet = Depends(),
    db: AsyncSession = Depends(get_db),
):
    """
    Get all files from the database.

    :param file_filter: The filter parameters for the files to retrieve.
    :return: A list of file data.
    """
    return await file_repository.get_files(db, file_filter)


async def get_file(file_id: int, db: AsyncSession = Depends(get_db)):
    """
    Get a file by its ID from the database.

    :param file_id: The ID of the file to retrieve.
    :return: The file data.
    """
    file = await file_repository.get_file_by_id(db, file_id)
    if file is None:
        raise HTTPException(status_code=404, detail="File not found")
    return file


async def delete_file(file_id: int, db: AsyncSession = Depends(get_db)):
    """
    Delete a file by its ID from the database.

    :param file_id: The ID of the file to delete.
    :return: The deleted file data.
    """
    file = await file_repository.get_file_by_id(db, file_id)
    if file is None:
        raise HTTPException(status_code=404, detail="File not found")
    await file_repository.delete_file_by_id(db, file_id)
    return file


async def update_file(
    file_id: int, file_data: FileUpdate, db: AsyncSession = Depends(get_db)
):
    """
    Update a file by its ID in the database.

    :param file_id: The ID of the file to update.
    :param file_data: The updated file data.
    :return: The updated file data.
    """
    file = await file_repository.update_file_by_id(db, file_id, file_data)
    if file is None:
        raise HTTPException(status_code=404, detail="File not found")
    return file


# Configuration endpoints
async def create_configuration(
    configuration: ConfigurationCreate, 
    db: AsyncSession = Depends(get_db)
):
    """
    Create a new configuration in the database.

    :param configuration: The configuration data to be stored in the database.
    :return: The created configuration data.
    """
    return await configuration_repository.create_configuration(db, configuration)


async def get_configuration(configuration_id: int, db: AsyncSession = Depends(get_db)):
    """
    Get a configuration by its ID from the database.

    :param configuration_id: The ID of the configuration to retrieve.
    :return: The configuration data.
    """
    configuration = await configuration_repository.get_configuration_by_id(db, configuration_id)
    if configuration is None:
        raise HTTPException(status_code=404, detail="Configuration not found")
    return configuration


async def get_all_configurations(db: AsyncSession = Depends(get_db)):
    """
    Get all configurations from the database.

    :return: A list of configuration data.
    """
    return await configuration_repository.get_all_configurations(db)


async def update_configuration(
    configuration_id: int, 
    configuration_data: ConfigurationUpdate, 
    db: AsyncSession = Depends(get_db)
):
    """
    Update a configuration by its ID in the database.

    :param configuration_id: The ID of the configuration to update.
    :param configuration_data: The updated configuration data.
    :return: The updated configuration data.
    """
    configuration = await configuration_repository.update_configuration_by_id(
        db, configuration_id, configuration_data
    )
    if configuration is None:
        raise HTTPException(status_code=404, detail="Configuration not found")
    return configuration


async def delete_configuration(configuration_id: int, db: AsyncSession = Depends(get_db)):
    """
    Delete a configuration by its ID from the database.

    :param configuration_id: The ID of the configuration to delete.
    :return: The deleted configuration data.
    """
    configuration = await configuration_repository.get_configuration_by_id(db, configuration_id)
    if configuration is None:
        raise HTTPException(status_code=404, detail="Configuration not found")
    await configuration_repository.delete_configuration(db, configuration_id)
    return configuration
