from typing import List, Optional

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from models import Batch, BatchCreate, BatchUpdate


class BatchRepository:
    """
    Repository class for the Batch model.
    This class contains methods for CRUD operations on the Batch model.
    """

    async def get_all_batches(
        self, db: AsyncSession, status: Optional[str] = None
    ) -> List[Batch]:
        """
        Get all batches from the database.
        :param db: AsyncSession: AsyncSession object
        :param status: Optional[str]: Status of the batch
        :return List[Batch]: List of Batch objects
        """
        query = select(Batch)
        if status:
            query = query.filter(Batch.status == status)
        result = await db.execute(query)
        return result.scalars().all()

    async def get_batch_by_id(self, db: AsyncSession, batch_id: int) -> Optional[Batch]:
        """
        Get a batch by its ID.
        :param db: AsyncSession: AsyncSession object
        :param batch_id: int: ID of the batch
        :return Optional[Batch]: Batch object
        """
        query = select(Batch).filter(Batch.id == batch_id)
        result = await db.execute(query)
        return result.scalars().first()

    async def create_batch(self, db: AsyncSession, batch: BatchCreate) -> Batch:
        """
        Create a new batch.
        :param db: AsyncSession: AsyncSession object
        :param batch: BatchCreate: BatchCreate object
        :return Batch: Batch object
        """
        batch = Batch(**batch.model_dump(exclude_unset=True))
        db.add(batch)
        await db.commit()
        await db.refresh(batch)
        return batch

    async def update_batch_by_id(
        self, db: AsyncSession, batch_id: int, batch: BatchUpdate
    ) -> Optional[Batch]:
        """
        Update a batch by its ID.
        :param db: AsyncSession: AsyncSession object
        :param batch_id: int: ID of the batch
        :param batch: BatchUpdate: BatchUpdate object
        :return Optional[Batch]: Batch object
        """
        query = select(Batch).filter(Batch.id == batch_id)
        result = await db.execute(query)
        _batch = result.scalars().first()
        if _batch:
            batch = batch.model_dump(exclude_unset=True)
            for key, value in batch.items():
                setattr(_batch, key, value)
            await db.commit()
            await db.refresh(_batch)
        return _batch

    async def delete_batch(self, db: AsyncSession, batch_id: int) -> bool:
        """
        Delete a batch by its ID. Cascade delete on files.
        :param db: AsyncSession: AsyncSession object
        :param batch_id: int: ID of the batch
        :return bool: True if the batch is deleted, False otherwise
        """
        query = select(Batch).filter(Batch.id == batch_id)
        result = await db.execute(query)
        batch = result.scalars().first()
        if batch:
            await db.delete(batch)
            await db.commit()
            return True
        return False
