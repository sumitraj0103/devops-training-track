from typing import List, Optional

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from models import File, FileCreate, FileGet, FileUpdate


class FileRepository:
    """
    Repository class for the File model.
    This class contains methods for CRUD operations on the File model.
    """

    async def add_file(self, db: AsyncSession, file: FileCreate) -> File:
        """
        Add a new file to the database.
        :param db: AsyncSession: AsyncSession object
        :param file: FileCreate: FileCreate object
        :return File: File object
        """
        file = File(**file.model_dump(exclude_unset=True))
        db.add(file)
        await db.commit()
        await db.refresh(file)
        return file

    async def get_files(self, db: AsyncSession, file_filter: FileGet) -> List[File]:
        """
        Get files from the database based on the filter.
        :param db: AsyncSession: AsyncSession object
        :param file_filter: FileGet: FileGet object
        :return List[File]: List of File objects
        """
        query = select(File)
        file_filter = file_filter.model_dump(exclude_unset=True)
        for attr, value in file_filter.items():
            if value is not None:
                query = query.filter(getattr(File, attr) == value)
        result = await db.execute(query)
        return result.scalars().all()

    async def get_file_by_id(self, db: AsyncSession, file_id: int) -> Optional[File]:
        """
        Get a file by its ID.
        :param db: AsyncSession: AsyncSession object
        :param file_id: int: ID of the file
        :return Optional[File]: File object
        """
        query = select(File).filter(File.id == file_id)
        result = await db.execute(query)
        return result.scalars().first()

    async def delete_file_by_id(self, db: AsyncSession, file_id: int) -> bool:
        """
        Delete a file by its ID.
        :param db: AsyncSession: AsyncSession object
        :param file_id: int: ID of the file
        :return bool: True if the file is deleted, False otherwise
        """
        query = select(File).filter(File.id == file_id)
        result = await db.execute(query)
        file = result.scalars().first()
        if file:
            await db.delete(file)
            await db.commit()
            return True
        return False

    async def update_file_by_id(
        self, db: AsyncSession, file_id: int, file: FileUpdate
    ) -> Optional[File]:
        """
        Update a file by its ID.
        :param db: AsyncSession: AsyncSession object
        :param file_id: int: ID of the file
        :param file: FileUpdate: FileUpdate object
        :return Optional[File]: File object
        """
        query = select(File).filter(File.id == file_id)
        result = await db.execute(query)
        _file = result.scalars().first()
        if _file:
            file = file.model_dump(exclude_unset=True)
            for key, value in file.items():
                setattr(_file, key, value)
            await db.commit()
            await db.refresh(_file)
        return _file
