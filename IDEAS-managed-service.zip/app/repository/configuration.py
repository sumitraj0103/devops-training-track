from typing import List, Optional

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from models import Configuration, ConfigurationCreate, ConfigurationUpdate


class ConfigurationRepository:
    """
    Repository class for the Configuration model.
    This class contains methods for CRUD operations on the Configuration model.
    """

    async def get_all_configurations(self, db: AsyncSession) -> List[Configuration]:
        """
        Get all configurations from the database.
        :param db: AsyncSession: AsyncSession object
        :return List[Configuration]: List of Configuration objects
        """
        query = select(Configuration)
        result = await db.execute(query)
        return result.scalars().all()

    async def get_configuration_by_id(
        self, db: AsyncSession, config_id: int
    ) -> Optional[Configuration]:
        """
        Get a configuration by its ID.
        :param db: AsyncSession: AsyncSession object
        :param config_id: int: ID of the configuration
        :return Optional[Configuration]: Configuration object
        """
        query = select(Configuration).filter(Configuration.id == config_id)
        result = await db.execute(query)
        return result.scalars().first()

    async def create_configuration(
        self, db: AsyncSession, configuration: ConfigurationCreate
    ) -> Configuration:
        """
        Create a new configuration.
        :param db: AsyncSession: AsyncSession object
        :param configuration: ConfigurationCreate: ConfigurationCreate object
        :return Configuration: Configuration object
        """
        configuration = Configuration(**configuration.model_dump(exclude_unset=True))
        db.add(configuration)
        await db.commit()
        await db.refresh(configuration)
        return configuration

    async def update_configuration_by_id(
        self, db: AsyncSession, config_id: int, configuration: ConfigurationUpdate
    ) -> Optional[Configuration]:
        """
        Update a configuration by its ID.
        :param db: AsyncSession: AsyncSession object
        :param config_id: int: ID of the configuration
        :param configuration: ConfigurationUpdate: ConfigurationUpdate object
        :return Optional[Configuration]: Configuration object
        """
        query = select(Configuration).filter(Configuration.id == config_id)
        result = await db.execute(query)
        _configuration = result.scalars().first()
        if _configuration:
            configuration = configuration.model_dump(exclude_unset=True)
            for key, value in configuration.items():
                setattr(_configuration, key, value)
            await db.commit()
            await db.refresh(_configuration)
        return _configuration

    async def delete_configuration(self, db: AsyncSession, config_id: int) -> bool:
        """
        Delete a configuration by its ID.
        :param db: AsyncSession: AsyncSession object
        :param config_id: int: ID of the configuration
        :return bool: True if the configuration is deleted, False otherwise
        """
        query = select(Configuration).filter(Configuration.id == config_id)
        result = await db.execute(query)
        configuration = result.scalars().first()
        if configuration:
            await db.delete(configuration)
            await db.commit()
            return True
        return False