import unittest

import requests


class TestSanity(unittest.TestCase):
    def __init__(self, methodName="runTest"):
        super().__init__(methodName)

        self.services = {
            "extract": "http://localhost:8082",
            "extract_implicit": "http://localhost:8083",
            "classify": "http://localhost:8081",
            "validate": "http://localhost:8080",
            "be": "http://localhost:8079",
            "fe": "http://localhost:3000",
            "tika": "http://localhost:9998"
        }

    def test_ping(self):
        for service, url in enumerate(
                [self.services.get(k) for k in ["extract", "extract_implicit", "validate", "classify"]]):
            response = requests.get(f'{url}/ping')
            self.assertEqual(response.status_code, 200, f"{service} ping endpoint failed")
            self.assertIn("pong", response.text, f"{service} ping response does not contain pong")

    def test_sanity_prompts(self):
        for service, url in enumerate([self.services.get(k) for k in ["extract", "extract_implicit", "validate"]]):
            response = requests.get(f'{url}/prompt')
            self.assertEqual(response.status_code, 200, f"{service} prompt endpoint failed")
            self.assertIn("system_prompt", response.json(),
                          f"{service} prompt response does not contain system_prompt key")
            self.assertIn("user_prompt", response.json(), f"{service} prompt response does not contain user_prompt key")
