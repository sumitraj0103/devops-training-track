import os
import json
import asyncio
import httpx

async def send_files_to_endpoint(directory, ground_truth_path, endpoint_url, batch_id, parser=None):
    """
    Sends files and their corresponding ground truth JSONs to the batch_file_evaluate endpoint.

    :param directory: Path to the directory containing the files to process.
    :param ground_truth_path: Path to the main ground truth JSON file.
    :param endpoint_url: URL of the batch_file_evaluate endpoint.
    :param batch_id: The batch ID to associate with the files.
    :param parser: Optional parser to use for processing the files (passed in the header).
    """
    # Load the main ground truth JSON file
    with open(ground_truth_path, "r") as f:
        ground_truth_data = json.load(f)

    # Prepare a list of tasks for sending files
    tasks = []

    # Loop through all files in the directory
    for file_name in os.listdir(directory):
        file_path = os.path.join(directory, file_name)
        # Check if the file is a file and not a directory
        if not os.path.isfile(file_path):
            continue

        # Check if the file has a corresponding ground truth in the main JSON
        if file_name not in ground_truth_data:
            print(f"Warning: No ground truth found for {file_name}, skipping.")
            continue

        # Create a small JSON file for the file's ground truth
        ground_truth = ground_truth_data[file_name]
        ground_truth_json = json.dumps(ground_truth)

        # Add the task to send the file and its ground truth to the endpoint
        tasks.append(
            send_file_to_endpoint(
                endpoint_url, batch_id, file_path, ground_truth_json, parser
            )
        )

    # Run all tasks concurrently
    await asyncio.gather(*tasks)
    print("All files have been sent to the endpoint.")


async def send_file_to_endpoint(endpoint_url, batch_id, file_path, ground_truth_json, parser=None):
    """
    Sends a single file and its ground truth JSON to the batch_file_evaluate endpoint.

    :param endpoint_url: URL of the batch_file_evaluate endpoint.
    :param batch_id: The batch ID to associate with the file.
    :param file_path: Path to the file to send.
    :param ground_truth_json: Ground truth JSON string for the file.
    :param parser: Optional parser to use for processing the file (passed in the header).
    """
    # Add the batchID as a query parameter in the URL
    url_with_query = f"{endpoint_url}?batchID={batch_id}"

    # Log the constructed URL for debugging
    print(f"Constructed URL: {url_with_query}")

    # Prepare headers
    headers = {}
    if parser:
        headers["parser"] = parser  # Add the parser to the headers

    # Set a custom timeout (e.g., 30 seconds)
    timeout = httpx.Timeout(30.0)  # Increase timeout to 30 seconds

    async with httpx.AsyncClient(timeout=timeout) as client:
        with open(file_path, "rb") as file:
            # Prepare the multipart form data
            files = {
                "document": (os.path.basename(file_path), file, "application/pdf"),
                "ground_truth": ("ground_truth.json", ground_truth_json, "application/json"),
            }

            # Send the POST request
            response = await client.post(url_with_query, files=files, headers=headers)

            # Print the response for debugging
            print(f"Response for {file_path}: {response.status_code} - {response.text}")


# Example usage
if __name__ == "__main__":
    # Directory containing the files to process
    directory = "/Users/Andrew/Downloads/Salary_Slips_Kaggle/common_folder"

    # Path to the main ground truth JSON file
    ground_truth_path = "/Users/Andrew/Downloads/groundTruthBatch1-5.json"

    # URL of the batch_file_evaluate endpoint
    endpoint_url = "http://127.0.0.1:8182/evaluate_batch_file"

    # Batch ID to associate with the files
    batch_id = 12

    # Optional parser to use (set to None if not needed)
    parser = "adi"

    # Run the function
    asyncio.run(send_files_to_endpoint(directory, ground_truth_path, endpoint_url, batch_id, parser))