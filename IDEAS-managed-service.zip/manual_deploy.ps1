$subscription_id= "3a1028f0-1402-44f3-b28a-bb2d76df1876"
$resource_group= "rg_test"
$environment= "appEnv"
$acr= "testazcrreadrobin.azurecr.io"
$image= "app_validate"
$tag= "latest"
$app_name= "test-name"
$azure_openai_key= "fghfgh"
$azure_openai_endpoint= "fghfgh"
$config="fghfg"

sed "s/#{subscription_id}#/$subscription_id/" ideas-ms-be/pipeline/containerApp.yml |
sed "s/#{resource_group}#/$resource_group/" |
sed "s/#{environment}#/$environment/" |
sed "s/#{acr}#/$acr/" |
sed "s/#{image}#/$image/" |
sed "s/#{tag}#/$tag/" |
sed "s/#{app_name}#/$app_name/" |
sed "s/#{azure_openai_key}#/$azure_openai_key/" |
sed "s/#{azure_openai_endpoint}#/$azure_openai_endpoint/" |
sed "s/#{config}#/$config/" > temp.yml

if (-Not(az group exists --name $resource_group))
{
    Write-Output "Resource group does not exist yet; creating and sleeping a couple of secs"
    az group create --location westeurope --name $resource_group 
    Start-Sleep 5
} else {
    Write-Output "Resource group exists; proceeding"
}
try {
     Get-AzContainerAppManagedEnv -Name $environment -ResourceGroupName $resource_group -Error -ErrorAction stop
} catch {
    Write-Output "App Env doesn't seem to exist, creating"
    $sn = New-AzVirtualNetworkSubnetConfig -Name "$app_name-capp-subnet" -AddressPrefix 10.0.0.0/23
    #Add-AzDelegation -Name "ca delegation" -ServiceName "Microsoft.App/environments" -Subnet $sn
    $network = New-AzVirtualNetwork -Name "$app_name-vnet" -ResourceGroupName $resource_group -Location westeurope -AddressPrefix "10.0.0.0/16" -Subnet $sn
    Start-Sleep 5
    New-AzContainerAppManagedEnv -Name $environment -ResourceGroupName $resource_group -location westeurope -VnetConfigurationInternal -VnetConfigurationInfrastructureSubnetId $network.Subnets[0].Id
    Start-Sleep 5
}

az containerapp create --name $app_name --resource-group $resource_group  --yaml temp.yml

rm temp.yml